import { sanitize } from "./sanitize.ts"
import type { AdmissionPacket, Outcome } from "./types.ts"
import type { SanitizeOptions, SanitizeResult } from "./sanitize.ts"

export const AUDIT_SCHEMA_VERSION = "loop-jev-audit/1"

/**
 * Pure audit boundary for an admitted request and its typed result. It retains
 * the decision fields needed for review, then sanitizes the entire projection
 * before returning a JSON-safe value. It neither persists nor transmits data.
 */
export function projectAudit(packet: AdmissionPacket, outcome: Outcome, options: SanitizeOptions = {}): SanitizeResult {
  return sanitize(
    {
      schemaVersion: AUDIT_SCHEMA_VERSION,
      projectId: packet.projectId,
      runId: packet.runId,
      decisionId: packet.decisionId,
      contract: packet.contract,
      admission: packet.admission,
      state: packet.state,
      questions: packet.questions,
      declaredFallback: packet.fallback ?? null,
      outcome: {
        accepted: outcome.accepted,
        status: outcome.status,
        runId: outcome.runId,
        decisionId: outcome.decisionId,
        contract: outcome.contract,
        answers: outcome.answers,
        fallback: outcome.fallback,
        reason: outcome.reason,
        composition: outcome.composition,
        output: outcome.output,
        pause: outcome.pause,
        decisionPath: outcome.decisionPath,
        attempt: outcome.attempt,
        auditErrors: outcome.auditErrors,
      },
    },
    options,
  )
}
