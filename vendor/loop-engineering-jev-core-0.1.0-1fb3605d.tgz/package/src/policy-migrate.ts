/** Lead-only command: requires an explicit file and all verified preconditions. */
import { migrateGlobalPolicyFile, migrateProjectStateFile } from "./state-policy.ts"
import { argv } from "node:process"

const args = new Map<string, string>()
for (let i = 2; i < argv.length; i += 2) if (argv[i]?.startsWith("--") && argv[i + 1]) args.set(argv[i]!.slice(2), argv[i + 1]!)
const path = args.get("path"), mode = args.get("mode"), expectedSha256 = args.get("expected-sha256"), schema = args.get("expected-schema"), expectedMode = args.get("expected-mode"), kind = args.get("kind")
if (!path || (mode !== "dry-run" && mode !== "apply") || !expectedSha256 || (schema !== "1" && schema !== '"1"' && schema !== "bootstrap-v1") || expectedMode !== "0600" || (kind !== "global-policy" && kind !== "project-state")) {
  throw new Error("usage: --kind global-policy|project-state --path FILE --mode dry-run|apply --expected-sha256 HEX --expected-schema 1|bootstrap-v1 --expected-mode 0600")
}
const expectedSchemaVersion = schema === "1" ? 1 : schema === '"1"' ? "1" : "bootstrap-v1"
const receipt = await (kind === "global-policy" ? migrateGlobalPolicyFile : migrateProjectStateFile)({ path, mode, expectedSha256, expectedSchemaVersion, expectedMode: 0o600 })
console.log(JSON.stringify(receipt, null, 2))
