#!/usr/bin/env node
import { readFileSync } from "node:fs"
import { resolve } from "node:path"
import { parseArgs } from "node:util"
import { runDecision, API_KEY_VARIABLE } from "./adapter.ts"
import { DEFAULT_TIMEOUT_MS } from "./types.ts"

const usage = "usage: loop-jev --packet <file|-> [--project-dir <dir>] [--policy <file>] [--timeout-ms <n>]"
async function main(): Promise<number> {
  let values: Record<string, string | boolean | undefined>
  try { values = parseArgs({ options: { packet: { type: "string" }, "project-dir": { type: "string" }, policy: { type: "string" }, "timeout-ms": { type: "string" }, help: { type: "boolean", short: "h" } }, strict: true }).values } catch { console.error(usage); return 2 }
  if (values.help || !values.packet) { console.error(usage); return values.help ? 0 : 2 }
  const timeoutMs = values["timeout-ms"] === undefined ? DEFAULT_TIMEOUT_MS : Number(values["timeout-ms"])
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) { console.error(`${usage}\n--timeout-ms must be a positive integer`); return 2 }
  let packet: unknown; try { packet = JSON.parse(readFileSync(values.packet === "-" ? 0 : resolve(values.packet as string), "utf8")) } catch { console.error("cannot read packet"); return 2 }
  const policyPath = values.policy === undefined ? {} : { policyPath: resolve(values.policy as string) }
  const apiKey = process.env[API_KEY_VARIABLE]
  const outcome = await runDecision(packet, { projectDir: resolve((values["project-dir"] as string | undefined) ?? process.cwd()), ...policyPath, ...(apiKey === undefined ? {} : { apiKey }), fetch: (url, init) => fetch(url, init), timeoutMs })
  console.log(JSON.stringify(outcome, null, 2)); return outcome.accepted ? 0 : 1
}
process.exitCode = await main()
