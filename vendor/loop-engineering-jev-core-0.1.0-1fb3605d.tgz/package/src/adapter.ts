import { homedir } from "node:os"
import { join } from "node:path"
import { acceptBatch } from "./accept.ts"
import { buildComposerRegistry } from "./compose.ts"
import { auditQuestions, normalizeClass, toWireQuestions, validatePacket } from "./packet.ts"
import { redactString, sanitize } from "./sanitize.ts"
import { validateGlobalPolicyV2, validateProjectStateV2 } from "./state-policy.ts"
import { appendEvent, LockError, nodeFs, projectPaths, readJson, realClock, withLock, writeJsonAtomic } from "./store.ts"
import { DECISION_SCHEMA_VERSION, DEFAULT_TIMEOUT_MS, EVENT_SCHEMA_VERSION, JEV_ENDPOINT, JEV_MODEL, TimeoutError } from "./types.ts"
import type { AcceptedAnswer, AdmissionPacket, Clock, Composer, FetchLike, JevFs, Outcome, Reason, ReasonCode } from "./types.ts"

export const API_KEY_VARIABLE = "TYPESAFE_LOOP_ENGINEERING_API_KEY"
export const MAX_RESPONSE_CHARS = 256 * 1024
const PAUSE = { state: "PAUSED(capability)", unblock: ["wait for Jev", "ask human"] } as const
export const defaultPolicyPath = (): string => join(homedir(), ".loop-engineering", "policy.json")
export type AdapterOptions = { projectDir: string; policyPath?: string; apiKey?: string; fetch: FetchLike; clock?: Clock; fs?: JevFs; timeoutMs?: number; composers?: readonly Composer[]; lockRetries?: number; lockRetryMs?: number }
const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v)
const empty = (): Outcome => ({ accepted: false, status: "rejected", runId: null, decisionId: null, contract: null, reason: null, output: null, composition: null, answers: null, fallback: null, pause: null, decisionPath: null, attempt: null, auditErrors: [] })
const reason = (code: ReasonCode, message: string): Reason => ({ code, message })

/** Exact normalized class membership; absent, malformed, and disabled policies deny. */
function billingClasses(routingPolicy: unknown): { allowsBillingClass(name: string): boolean } | null {
  if (!isRecord(routingPolicy) || !isRecord(routingPolicy.billingClasses)) return null
  const enabled = new Set<string>()
  for (const [name, value] of Object.entries(routingPolicy.billingClasses)) {
    if (typeof value !== "boolean" || !name || !normalizeClass(name)) return null
    if (value) enabled.add(normalizeClass(name))
  }
  return { allowsBillingClass: name => enabled.has(normalizeClass(name)) }
}

/** One transport attempt only. The credential is injected by the caller and is never read from any legacy variable. */
export async function runDecision(rawPacket: unknown, options: AdapterOptions): Promise<Outcome> {
  const fs = options.fs ?? nodeFs, clock = options.clock ?? realClock, paths = projectPaths(options.projectDir), outcome = empty(), secrets = options.apiKey ? [options.apiKey] : []
  const policyRaw = await readJson(fs, options.policyPath ?? defaultPolicyPath()).catch(() => null)
  const policy = validateGlobalPolicyV2(policyRaw)
  if (!policy.ok) return denied("denied.policy-unavailable", "global v2 policy is unavailable", null)
  const billing = billingClasses(policy.value.routingPolicy)
  if (!billing) return denied("denied.policy-unavailable", "global policy billingClasses is unavailable", null)
  const registry = buildComposerRegistry(options.composers)
  const checked = validatePacket(rawPacket, billing, registry, secrets)
  outcome.runId = checked.ok ? checked.packet.runId : checked.runId; outcome.decisionId = checked.ok ? checked.packet.decisionId : checked.decisionId
  if (!checked.ok) return denied(checked.reason.code, checked.reason.message, null)
  const { packet, composer } = checked; outcome.contract = packet.contract; outcome.composition = packet.composition
  // Missing/empty is denied before acquiring a lock, writing state, or invoking transport.
  if (!options.apiKey?.trim()) return denied("denied.missing-api-key", `${API_KEY_VARIABLE} is not set`, packet)
  const lock = { ...(options.lockRetries === undefined ? {} : { retries: options.lockRetries }), ...(options.lockRetryMs === undefined ? {} : { retryMs: options.lockRetryMs }) }
  const decisionPath = paths.decisionPath(packet.runId, packet.decisionId)
  let attempt: number
  try {
    const opened = await withLock(fs, clock, paths.lockPath, lock, () => openAttempt(fs, clock, paths, policy.value.declarationCaps.maxLifetimeModelProviderRequestsPerProject, packet, decisionPath))
    if ("failure" in opened) return denied(opened.failure.code, opened.failure.message, packet)
    attempt = opened.attempt
  } catch (error) { return denied(error instanceof LockError ? "denied.lock" : "failed.charge-write", "state charge could not be atomically recorded", packet) }
  outcome.attempt = attempt; outcome.decisionPath = decisionPath
  let raw: unknown = null, failed: Reason | null = null, httpStatus: number | null = null
  const timer = clock.timeout(options.timeoutMs ?? DEFAULT_TIMEOUT_MS), controller = new AbortController()
  try { const response = await Promise.race([options.fetch(JEV_ENDPOINT, { method: "POST", headers: { Authorization: `Bearer ${options.apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ model: JEV_MODEL, state: packet.state, questions: toWireQuestions(packet.questions) }), signal: controller.signal }), timer.promise]); httpStatus = response.status; const text = await Promise.race([response.text(), timer.promise]); if (text.length > MAX_RESPONSE_CHARS) failed = reason("failed.malformed-response", "response exceeds the size bound"); else { try { raw = JSON.parse(text) } catch { failed = reason("failed.malformed-response", "response is not valid JSON") } }; if (!failed && (httpStatus < 200 || httpStatus >= 300)) failed = reason("failed.http", `HTTP ${httpStatus}`) } catch (error) { controller.abort(); failed = error instanceof TimeoutError ? reason("failed.timeout", error.message) : reason("failed.network", "transport error") } finally { timer.cancel() }
  let answers: Record<string, AcceptedAnswer> | null = null, output: Outcome["output"] = null
  if (!failed) {
    const supplied = isRecord(raw) && isRecord(raw.answers) ? raw.answers : null
    if (!supplied) failed = reason("failed.malformed-response", "response has no answers object")
    else if (Object.keys(supplied).length !== packet.questions.length || packet.questions.some(q => !(q.id in supplied))) failed = reason("failed.answer-set", "response question IDs do not exactly match the packet")
    else { const batch = acceptBatch(packet.questions, supplied); if (!batch.usable) failed = batch.firstFailure!; else { answers = Object.fromEntries(Object.entries(batch.results).map(([id, verdict]) => [id, (verdict as { ok: true; answer: AcceptedAnswer }).answer])); try { output = composer.compose(answers, packet.questions) } catch { failed = reason("failed.composition", "composition failed"); answers = null } } }
  }
  const usable = !failed, fallback = !usable && packet.fallback ? { ...packet.fallback } : null, pause = !usable && !fallback ? PAUSE : null
  const sanitizedState = sanitize(packet.state, { secrets, maxBytes: 16 * 1024 })
  const record = { schemaVersion: DECISION_SCHEMA_VERSION, projectId: packet.projectId, runId: packet.runId, decisionId: packet.decisionId, contract: packet.contract, status: usable ? "completed" : "failed", accepted: usable, attempt: { number: attempt, httpStatus, endpoint: JEV_ENDPOINT, model: JEV_MODEL }, admission: packet.admission, questions: auditQuestions(packet.questions), state: sanitizedState.ok ? sanitizedState.value : "[unloggable state]", answers, composition: usable ? { ...packet.composition, output } : null, reason: failed, fallback, pause }
  try { await withLock(fs, clock, paths.lockPath, lock, async () => { await writeJsonAtomic(fs, decisionPath, record, clock); await appendEvent(fs, paths.eventsPath, { schemaVersion: EVENT_SCHEMA_VERSION, at: clock.now().toISOString(), type: "jev.decision.resolved", projectId: packet.projectId, runId: packet.runId, decisionId: packet.decisionId, contract: packet.contract, attempt, accepted: usable, reason: failed, fallback, pause, decisionPath: `runs/${packet.runId}/decisions/${packet.decisionId}.json` }) }) } catch { return denied("failed.log-write", "decision result could not be persisted", packet, attempt, decisionPath) }
  Object.assign(outcome, { accepted: usable, status: usable ? "accepted" : "failed", reason: failed, output: usable ? output : null, answers: usable ? answers : null, fallback, pause })
  return outcome

  async function denied(code: ReasonCode, message: string, packet: AdmissionPacket | null, attempt: number | null = null, decisionPath: string | null = null): Promise<Outcome> { const fallback = packet?.fallback ? { ...packet.fallback } : null; return { ...outcome, status: code.startsWith("failed.") ? "failed" : "denied", reason: reason(code, redactString(message, secrets)), fallback, pause: fallback ? null : PAUSE, attempt, decisionPath } }
}

async function openAttempt(fs: JevFs, clock: Clock, paths: ReturnType<typeof projectPaths>, policyMax: number, packet: AdmissionPacket, decisionPath: string): Promise<{ attempt: number } | { failure: Reason }> {
  const stateRaw = await readJson(fs, paths.statePath).catch(() => null), state = validateProjectStateV2(stateRaw)
  if (!state.ok) return { failure: reason("denied.state-unavailable", "project v2 state is unavailable") }
  if (state.value.projectId !== packet.projectId) return { failure: reason("packet.unauthorized", "packet project does not match state") }
  if (!state.value.requestCounters) return { failure: reason("denied.state-unavailable", "project state lacks named request counters") }
  const counters = state.value.requestCounters
  if (counters.lifetimeModelProviderRequests + 1 > policyMax) return { failure: reason("denied.call-budget", "lifetime model/provider request budget exhausted") }
  if (await fs.exists(decisionPath)) return { failure: reason("packet.duplicate-decision", "decision already exists") }
  const next = counters.lifetimeModelProviderRequests + 1
  await writeJsonAtomic(fs, paths.statePath, { ...state.value, requestCounters: { lifetimeModelProviderRequests: next, jevRequests: counters.jevRequests + 1 } }, clock)
  await writeJsonAtomic(fs, decisionPath, { schemaVersion: DECISION_SCHEMA_VERSION, projectId: packet.projectId, runId: packet.runId, decisionId: packet.decisionId, contract: packet.contract, status: "requested", accepted: false, attempt: { number: next, endpoint: JEV_ENDPOINT, model: JEV_MODEL }, note: "request charged before transport; interrupted attempts remain charged" }, clock)
  await appendEvent(fs, paths.eventsPath, { schemaVersion: EVENT_SCHEMA_VERSION, at: clock.now().toISOString(), type: "jev.decision.requested", projectId: packet.projectId, runId: packet.runId, decisionId: packet.decisionId, contract: packet.contract, attempt: next })
  return { attempt: next }
}
