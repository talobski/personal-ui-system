/** Phase 5 pure control-plane contracts.  They neither dispatch nor mutate live state. */
import { digestQuestions } from "./packet.ts"
import { sha256, stableJson } from "./state-policy.ts"
import type { Check } from "./state-policy.ts"
import type { AdmissionPacket, Question } from "./types.ts"
import type { WorkerProfile } from "./profile-routing.ts"

const fail = <T>(...errors: string[]): Check<T> => ({ ok: false, errors })
const text = (value: unknown): value is string => typeof value === "string" && value.length > 0
const hash = (value: unknown) => sha256(stableJson(value))
export const MODEL_CLASS_V1 = "loop-model-class/1"
export type ModelClass = "STANDARD" | "STRONG" | "MAX"
export type ContinuationContract = "RETRY_STRATEGY" | "HUMAN_INTERRUPT"

export type ContinuationOption = { id: string; kind: "retry" | "interrupt"; safe: boolean; withinHeadroom: boolean }
export type ContinuationResult = { action: "EXECUTE"; option: ContinuationOption; logged: true } | { action: "DECIDE"; contract: ContinuationContract; options: readonly ContinuationOption[] } | { action: "FAIL_CLOSED"; reason: "HARD_BOUNDARY" | "HEADROOM_EXHAUSTED" | "NO_SAFE_OPTION" }
/** A single safe bounded option is never sent to Jev. */
export function decideContinuation(options: readonly ContinuationOption[], hardBoundary: boolean, headroom: number): ContinuationResult {
  if (hardBoundary) return { action: "FAIL_CLOSED", reason: "HARD_BOUNDARY" }
  if (!Number.isSafeInteger(headroom) || headroom <= 0) return { action: "FAIL_CLOSED", reason: "HEADROOM_EXHAUSTED" }
  const safe = options.filter(option => text(option.id) && option.safe && option.withinHeadroom)
  if (safe.length === 0) return { action: "FAIL_CLOSED", reason: "NO_SAFE_OPTION" }
  if (safe.length === 1) return { action: "EXECUTE", option: safe[0]!, logged: true }
  return { action: "DECIDE", contract: safe.some(option => option.kind === "interrupt") ? "HUMAN_INTERRUPT" : "RETRY_STRATEGY", options: safe }
}

export type VerifierPreflight = { verifierId: string; candidateCommit: string; candidateHash: string; controlHash: string; expectedCandidateCommit: string; expectedCandidateHash: string; expectedControlHash: string; currentPathCapabilities: readonly string[]; requiredCapabilities: readonly string[]; protectedRunReserved: true }
export type PreDispatchReceipt = { schemaVersion: "loop-pre-verifier-receipt/1"; verifierId: string; candidateCommit: string; candidateHash: string; controlHash: string; dispatchAllowed: true; protectedRunConsumed: false }
export function preflightVerifier(input: VerifierPreflight): Check<PreDispatchReceipt> {
  if (!text(input.verifierId) || !text(input.candidateCommit) || !text(input.candidateHash) || !text(input.controlHash) || !input.protectedRunReserved || input.candidateCommit !== input.expectedCandidateCommit || input.candidateHash !== input.expectedCandidateHash || input.controlHash !== input.expectedControlHash || !input.requiredCapabilities.every(capability => input.currentPathCapabilities.includes(capability))) return fail("verifier preflight capability, candidate, or control receipt mismatch")
  return { ok: true, value: { schemaVersion: "loop-pre-verifier-receipt/1", verifierId: input.verifierId, candidateCommit: input.candidateCommit, candidateHash: input.candidateHash, controlHash: input.controlHash, dispatchAllowed: true, protectedRunConsumed: false } }
}

export type VerificationOutcome = "PASS" | "FAIL_PRODUCT" | "FAIL_CONTRACT" | "BLOCKED_ENVIRONMENT" | "BLOCKED_CAPABILITY"
export function classifyVerificationOutcome(input: { productFailure?: boolean; contractFailure?: boolean; environmentBlocked?: boolean; capabilityBlocked?: boolean }): VerificationOutcome {
  if (input.capabilityBlocked) return "BLOCKED_CAPABILITY"
  if (input.environmentBlocked) return "BLOCKED_ENVIRONMENT"
  if (input.contractFailure) return "FAIL_CONTRACT"
  return input.productFailure ? "FAIL_PRODUCT" : "PASS"
}
export type Evidence = { source: "FRESH_VERIFIER" | "LEAD" | "BLOCKED_ENVIRONMENT"; candidateCommit: string; scopeHash: string; outcome: VerificationOutcome }
export function acceptEvidence(evidence: Evidence, requiresFreshVerifier: boolean): Check<Evidence> {
  if (!text(evidence.candidateCommit) || !text(evidence.scopeHash) || !["PASS", "FAIL_PRODUCT", "FAIL_CONTRACT", "BLOCKED_ENVIRONMENT", "BLOCKED_CAPABILITY"].includes(evidence.outcome)) return fail("evidence malformed")
  if (requiresFreshVerifier && (evidence.source !== "FRESH_VERIFIER" || evidence.outcome !== "PASS")) return fail("Lead or blocked evidence cannot satisfy fresh verifier evidence")
  if (evidence.source === "BLOCKED_ENVIRONMENT" && !evidence.outcome.startsWith("BLOCKED_")) return fail("blocked evidence has false provenance")
  return { ok: true, value: evidence }
}

export type RecoveryRequest = { verifierId: string; candidateCommit: string; scopeHash: string; controlHash: string; permissionHash: string; initial: { verifierId: string; candidateCommit: string; scopeHash: string; controlHash: string; permissionHash: string }; newAgentRun: false; network: false; credentialAccess: false; paidSpend: 0; concurrency: 1; productMutation: false; testMutation: false }
export function admitSameVerifierRecovery(request: RecoveryRequest): Check<{ recovery: "SAME_VERIFIER"; attempts: 1 }> {
  const same = request.verifierId === request.initial.verifierId && request.candidateCommit === request.initial.candidateCommit && request.scopeHash === request.initial.scopeHash && request.controlHash === request.initial.controlHash && request.permissionHash === request.initial.permissionHash
  return same && !request.newAgentRun && !request.network && !request.credentialAccess && request.paidSpend === 0 && request.concurrency === 1 && !request.productMutation && !request.testMutation ? { ok: true, value: { recovery: "SAME_VERIFIER", attempts: 1 } } : fail("same-verifier recovery broadened identity, scope, capability, or counters")
}

export type ClassBoundProfile = { profile: WorkerProfile; modelClass: Exclude<ModelClass, "MAX">; profileHash: string; bindingHash: string }
export function bindModelClass(profile: WorkerProfile, modelClass: Exclude<ModelClass, "MAX">): ClassBoundProfile { const profileHash = hash(profile); return { profile, modelClass, profileHash, bindingHash: hash({ modelClass, profileHash }) } }
export function composeModelClassPacket(classes: readonly ModelClass[], runId: string, decisionId: string): Check<AdmissionPacket | null> {
  const unique = [...new Set(classes)].sort()
  if (unique.length === 0) return fail("no admitted model class")
  if (unique.length === 1) return { ok: true, value: null }
  const questions: Question[] = [{ id: "modelClass", type: "choice", instructions: "Select only an admitted model class.", options: unique.map(id => ({ id, description: `admitted ${id} class` })) }]
  return { ok: true, value: { schemaVersion: "loop-jev-admission/1", projectId: "loop-engineering-runtime", runId, decisionId, contract: "MODEL_CLASS", composition: { id: "direct-choice", version: "1" }, admission: { gate: "phase-5-class-admission", questionsDigest: digestQuestions("MODEL_CLASS", questions), authority: { billingClass: "included", paidCapacity: false, permissionEscalation: false, verificationWaived: false, completionWaived: false, completionPreconditionsPassed: false } }, state: { modelClasses: unique }, questions } }
}
/** ROUTE_PROFILE may only see profiles selected by the preceding class decision. */
export function filterRoutesForClass(profiles: readonly ClassBoundProfile[], selected: ModelClass): Check<readonly ClassBoundProfile[]> { if (selected === "MAX") return fail("MAX has no autonomous route"); const filtered = profiles.filter(profile => profile.modelClass === selected); return filtered.length ? { ok: true, value: filtered } : fail("cross-class fallback is forbidden") }

export type MaxRecommendation = { taskId: string; profileId: string; model: string; effort: "medium"; recommended: true }
export type OwnerApproval = MaxRecommendation & { approvalId: string; nonce: string; ownerApproved: true }
export function consumeMaxApproval(recommendation: MaxRecommendation, approval: OwnerApproval | undefined, usedApprovalIds: ReadonlySet<string>): Check<{ dispatch: "MAX"; consumedApprovalId: string }> {
  if (!approval || !text(approval.approvalId) || !text(approval.nonce) || usedApprovalIds.has(approval.approvalId) || !approval.ownerApproved || approval.taskId !== recommendation.taskId || approval.profileId !== recommendation.profileId || approval.model !== recommendation.model || approval.effort !== recommendation.effort) return fail("MAX approval missing, mismatched, persistent, or replayed")
  return { ok: true, value: { dispatch: "MAX", consumedApprovalId: approval.approvalId } }
}

export type StrongActivationPlan = { schemaVersion: "loop-strong-activation-plan/1"; candidateCommit: string; verificationEvidenceHash: string; profiles: readonly { profileId: string; profileHash: string }[]; preconditions: { registryHash: string; controlsHash: string; exactPass: true }; rollback: { beforeRegistryHash: string; required: true }; activation: false; leadOnly: true }
export function createStrongActivationPlan(candidateCommit: string, verification: Evidence, profiles: readonly ClassBoundProfile[], registryHash: string, controlsHash: string): Check<StrongActivationPlan> {
  if (!text(candidateCommit) || verification.candidateCommit !== candidateCommit || !acceptEvidence(verification, true).ok || profiles.length === 0 || !text(registryHash) || !text(controlsHash) || profiles.some(profile => profile.modelClass !== "STRONG")) return fail("Strong activation requires exact fresh PASS and Strong-only hashes")
  return { ok: true, value: { schemaVersion: "loop-strong-activation-plan/1", candidateCommit, verificationEvidenceHash: hash(verification), profiles: profiles.map(profile => ({ profileId: profile.profile.id, profileHash: profile.bindingHash })), preconditions: { registryHash, controlsHash, exactPass: true }, rollback: { beforeRegistryHash: registryHash, required: true }, activation: false, leadOnly: true } }
}

/** Phase 6 contracts are pure receipts: they do not create workers or touch policy. */
export const EXECUTION_POLICY_V1 = "loop-execution-policy/1"
export type OperationalFailureClass = "ARTIFACT_FAILURE" | "ENVIRONMENT_BLOCK" | "CAPABILITY_BLOCK"
export type ExecutionPolicy = {
  schemaVersion: typeof EXECUTION_POLICY_V1
  phaseId: string
  migration: "NEW" | "EXPLICIT_MIGRATION"
  lifetime: { maxAgentRuns: number; usedAgentRuns: number }
  phase: { maxAgentCreations: number; usedAgentCreations: number; cumulativeWallClockMs: number; maxWallClockMs: number; protectedVerifierReserved: true }
  telemetry: { leadTurns: number; phaseAttempts: number; recoverySteps: number }
  hardControls: { concurrency: 1; paidSpend: 0; network: false; credentialAccess: false; externalAction: false }
}
const whole = (value: unknown): value is number => typeof value === "number" && Number.isSafeInteger(value) && value >= 0
/** Legacy phases stay on their existing strict admission path until named migration. */
export function admitExecutionPolicy(policy: ExecutionPolicy, requestedAgentCreations: number, elapsedWallClockMs: number): Check<ExecutionPolicy> {
  if (policy.schemaVersion !== EXECUTION_POLICY_V1 || !text(policy.phaseId) || !(policy.migration === "NEW" || policy.migration === "EXPLICIT_MIGRATION") || !whole(requestedAgentCreations) || !whole(elapsedWallClockMs) || !whole(policy.lifetime.maxAgentRuns) || !whole(policy.lifetime.usedAgentRuns) || !whole(policy.phase.maxAgentCreations) || !whole(policy.phase.usedAgentCreations) || !whole(policy.phase.cumulativeWallClockMs) || !whole(policy.phase.maxWallClockMs) || !policy.phase.protectedVerifierReserved || !whole(policy.telemetry.leadTurns) || !whole(policy.telemetry.phaseAttempts) || !whole(policy.telemetry.recoverySteps) || policy.hardControls.concurrency !== 1 || policy.hardControls.paidSpend !== 0 || policy.hardControls.network || policy.hardControls.credentialAccess || policy.hardControls.externalAction) return fail("execution policy is malformed or relaxes a hard control")
  if (policy.lifetime.usedAgentRuns + requestedAgentCreations > policy.lifetime.maxAgentRuns || policy.phase.usedAgentCreations + requestedAgentCreations > policy.phase.maxAgentCreations || policy.phase.cumulativeWallClockMs + elapsedWallClockMs > policy.phase.maxWallClockMs) return fail("project lifetime or cumulative phase envelope exhausted")
  return { ok: true, value: policy }
}
export type ExecutionTimeSupervisor = { schemaVersion: "loop-execution-time-supervisor/1"; phaseId: string; startedAtMs: number; stoppedWaits: readonly { startedAtMs: number; endedAtMs: number; fullyStopped: true }[]; observedAtMs: number }
/** Overlap counts once because exclusion is computed as the union of fully stopped intervals. */
export function cumulativeExecutionMs(supervisor: ExecutionTimeSupervisor): Check<number> {
  if (supervisor.schemaVersion !== "loop-execution-time-supervisor/1" || !text(supervisor.phaseId) || !whole(supervisor.startedAtMs) || !whole(supervisor.observedAtMs) || supervisor.observedAtMs < supervisor.startedAtMs || !Array.isArray(supervisor.stoppedWaits)) return fail("execution supervisor is malformed")
  const intervals = supervisor.stoppedWaits.map(wait => wait).sort((a, b) => a.startedAtMs - b.startedAtMs)
  if (intervals.some(wait => !whole(wait.startedAtMs) || !whole(wait.endedAtMs) || !wait.fullyStopped || wait.endedAtMs < wait.startedAtMs || wait.startedAtMs < supervisor.startedAtMs || wait.endedAtMs > supervisor.observedAtMs)) return fail("stopped wait is not fully recorded within phase time")
  let excluded = 0, end = -1
  for (const wait of intervals) { const start = Math.max(wait.startedAtMs, end); if (wait.endedAtMs > start) { excluded += wait.endedAtMs - start; end = wait.endedAtMs } }
  return { ok: true, value: supervisor.observedAtMs - supervisor.startedAtMs - excluded }
}
export type GateDerivedContinuation = { gate: "READY_FOR_G7"; admissible: true; evidenceHash: string }
/** The deterministic READY_FOR_G7 singleton is final: Jev is reserved for multiple choices only. */
export function decideGateDerivedContinuation(input: GateDerivedContinuation | null, hardGatePassed: boolean): ContinuationResult {
  if (!hardGatePassed || !input || !text(input.evidenceHash)) return { action: "FAIL_CLOSED", reason: "HARD_BOUNDARY" }
  return { action: "EXECUTE", option: { id: input.gate, kind: "retry", safe: true, withinHeadroom: true }, logged: true }
}
export type CriterionCapability = { criterionId: string; requiredCapabilities: readonly string[] }
export type VerifierReadiness = { profileId: string; environmentId: string; candidateCommit: string; artifactHash: string; criteria: readonly CriterionCapability[]; availableCapabilities: readonly string[]; protectedRunReserved: true }
export type VerifierReadinessReceipt = { schemaVersion: "loop-verifier-readiness/1"; profileId: string; environmentId: string; candidateCommit: string; artifactHash: string; criteriaHash: string; protectedRunConsumed: false }
export function checkVerifierReadiness(input: VerifierReadiness): Check<VerifierReadinessReceipt> {
  if (!text(input.profileId) || !text(input.environmentId) || !text(input.candidateCommit) || !text(input.artifactHash) || !input.protectedRunReserved || input.criteria.length === 0 || input.criteria.some(criterion => !text(criterion.criterionId) || criterion.requiredCapabilities.length === 0 || !criterion.requiredCapabilities.every(text) || !criterion.requiredCapabilities.every(capability => input.availableCapabilities.includes(capability)))) return fail("criterion-scoped verifier readiness failed before dispatch")
  return { ok: true, value: { schemaVersion: "loop-verifier-readiness/1", profileId: input.profileId, environmentId: input.environmentId, candidateCommit: input.candidateCommit, artifactHash: input.artifactHash, criteriaHash: hash(input.criteria), protectedRunConsumed: false } }
}
export function classifyOperationalFailure(input: { artifactFailure?: boolean; environmentBlocked?: boolean; capabilityBlocked?: boolean }): OperationalFailureClass | null {
  if (input.capabilityBlocked) return "CAPABILITY_BLOCK"
  if (input.environmentBlocked) return "ENVIRONMENT_BLOCK"
  return input.artifactFailure ? "ARTIFACT_FAILURE" : null
}
export type AggregatedEvidence = Evidence & { detailHash: string; fresh: boolean }
export function aggregateVerificationEvidence(evidence: readonly AggregatedEvidence[], candidateCommit: string, requiresFreshVerifier: boolean): Check<{ outcome: "PASS" | OperationalFailureClass; evidence: readonly AggregatedEvidence[] }> {
  if (!text(candidateCommit) || evidence.length === 0 || evidence.some(item => item.candidateCommit !== candidateCommit || !text(item.detailHash) || !acceptEvidence(item, false).ok || (item.source === "FRESH_VERIFIER") !== item.fresh)) return fail("verification evidence is malformed or provenance drifted")
  const freshEvidence = evidence.some(item => item.source === "FRESH_VERIFIER")
  if (requiresFreshVerifier && !freshEvidence) return fail("fresh verifier evidence is required and cannot be supplied by Lead evidence")
  const failure = evidence.find(item => item.outcome === "FAIL_PRODUCT" || item.outcome === "FAIL_CONTRACT")
  if (failure) return { ok: true, value: { outcome: "ARTIFACT_FAILURE", evidence } }
  const block = evidence.find(item => item.outcome === "BLOCKED_CAPABILITY" || item.outcome === "BLOCKED_ENVIRONMENT")
  if (block) return { ok: true, value: { outcome: block.outcome === "BLOCKED_CAPABILITY" ? "CAPABILITY_BLOCK" : "ENVIRONMENT_BLOCK", evidence } }
  return { ok: true, value: { outcome: "PASS", evidence } }
}
export type PermissionResolution = "GRANTED" | "BLOCKED_CAPABILITY" | "OWNER_REQUIRED"
export function resolvePermissionOnce(input: { requestId: string; requested: true; reconciliation: "GRANTED" | "DENIED_CAPABILITY" | "OWNER_REQUIRED"; priorRequests: number }): Check<PermissionResolution> {
  if (!text(input.requestId) || !input.requested || input.priorRequests !== 0) return fail("permission requests must not be polled or replayed")
  return { ok: true, value: input.reconciliation === "GRANTED" ? "GRANTED" : input.reconciliation === "DENIED_CAPABILITY" ? "BLOCKED_CAPABILITY" : "OWNER_REQUIRED" }
}
export type CurrentControlReceipt = { schemaVersion: "loop-current-control-receipt/1"; candidateCommit: string; artifactHash: string; executionPolicyHash: string; concurrency: 1; paidSpend: 0; verifierId: string; verifierScopeHash: string; capabilitiesHash: string; controlMetadataHash: string }
export function createCurrentControlReceipt(input: Omit<CurrentControlReceipt, "schemaVersion">, policy: ExecutionPolicy, capabilities: readonly string[]): Check<CurrentControlReceipt> {
  if (!text(input.candidateCommit) || !text(input.artifactHash) || !text(input.verifierId) || !text(input.verifierScopeHash) || !text(input.controlMetadataHash) || input.concurrency !== 1 || input.paidSpend !== 0 || input.executionPolicyHash !== hash(policy) || input.capabilitiesHash !== hash([...capabilities].sort()) || !admitExecutionPolicy(policy, 0, 0).ok) return fail("candidate/control receipt is stale or unsafe")
  return { ok: true, value: { schemaVersion: "loop-current-control-receipt/1", ...input } }
}
export function admitBoundedRecovery(request: RecoveryRequest & { policy: ExecutionPolicy; recoveryStep: number; newEvidence: boolean; measurableProgress: boolean }): Check<{ recovery: "SAME_VERIFIER"; attempts: 1 }> {
  if (!admitSameVerifierRecovery(request).ok || !admitExecutionPolicy(request.policy, 0, 0).ok || !whole(request.recoveryStep) || request.recoveryStep > 2 || (request.recoveryStep === 2 && !request.newEvidence && !request.measurableProgress)) return fail("recovery exceeded phase envelope or stopped without evidence/progress")
  return { ok: true, value: { recovery: "SAME_VERIFIER", attempts: 1 } }
}
export type OptedInActivationPlan = { schemaVersion: "loop-opted-in-activation-plan/1"; phaseId: string; targetPolicyHash: string; verificationCandidateCommit: string; activation: false; leadOnly: true; explicitMigration: true; preconditions: { freshPass: true; beforeHash: string; mode: "0600" }; rollback: { backupHash: string; required: true } }
export function createOptedInActivationPlan(phaseId: string, targetPolicy: ExecutionPolicy, freshVerification: Evidence, beforeHash: string, backupHash: string): Check<OptedInActivationPlan> {
  if (!text(phaseId) || targetPolicy.phaseId !== phaseId || targetPolicy.migration !== "EXPLICIT_MIGRATION" || !admitExecutionPolicy(targetPolicy, 0, 0).ok || !acceptEvidence(freshVerification, true).ok || !text(beforeHash) || !text(backupHash)) return fail("activation requires an explicitly migrated phase and exact fresh PASS")
  return { ok: true, value: { schemaVersion: "loop-opted-in-activation-plan/1", phaseId, targetPolicyHash: hash(targetPolicy), verificationCandidateCommit: freshVerification.candidateCommit, activation: false, leadOnly: true, explicitMigration: true, preconditions: { freshPass: true, beforeHash, mode: "0600" }, rollback: { backupHash, required: true } } }
}
