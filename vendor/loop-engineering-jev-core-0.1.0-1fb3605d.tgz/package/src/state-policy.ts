/**
 * Phase 2 durable state contracts.  These functions are deliberately pure
 * except for the explicit Lead-operated file migration at the bottom.
 * They never discover a policy path and never contact a provider.
 */
import { createHash } from "node:crypto"
import { basename, dirname, join } from "node:path"
import { chmod, lstat, readFile, rename, unlink, writeFile } from "node:fs/promises"
import type { Json, JsonObject } from "./types.ts"

export const GLOBAL_POLICY_V2 = "loop-global-policy/2"
export const PROJECT_STATE_V2 = "loop-project-state/2"
export type Check<T> = { ok: true; value: T } | { ok: false; errors: readonly string[] }
const record = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v)
const json = (v: unknown): v is Json => v === null || typeof v === "string" || typeof v === "number" || typeof v === "boolean" || (Array.isArray(v) && v.every(json)) || (record(v) && Object.values(v).every(json))
const fail = <T>(...errors: string[]): Check<T> => ({ ok: false, errors })
const exact = (v: Record<string, unknown>, allowed: readonly string[], where: string): string | null => Object.keys(v).find(k => !allowed.includes(k)) ? `${where} contains unknown field "${Object.keys(v).find(k => !allowed.includes(k))}"` : null
const nonnegative = (v: unknown): v is number => typeof v === "number" && Number.isSafeInteger(v) && v >= 0
const cleanMetadata = (v: unknown, where: string): string | null => {
  if (!record(v) || !json(v)) return `${where} must be a JSON object`
  const visit = (value: Json): string | null => {
    if (Array.isArray(value)) { for (const item of value) { const error = visit(item); if (error) return error } }
    else if (record(value)) for (const [key, item] of Object.entries(value)) {
      if (/(credential|secret|token|api[_-]?key|authorization|password)/i.test(key)) return `${where} contains prohibited credential-shaped field "${key}"`
      if (/^(projectId|taskId|tasks|inFlight|counters|lifetime|phasePlan|phaseAllocation|results)$/i.test(key)) return `${where} contains project-scoped field "${key}"`
      const error = visit(item as Json); if (error) return error
    }
    return null
  }
  const error = visit(v); if (error) return error
  return null
}
const cleanProjectPayload = (v: unknown, where: string): string | null => {
  if (!record(v) || !json(v)) return `${where} must be a JSON object`
  const visit = (value: Json): string | null => Array.isArray(value) ? value.map(visit).find((error): error is string => error !== null) ?? null : record(value) ? Object.entries(value).map(([key, item]) => /(credential|secret|token|api[_-]?key|authorization|password)/i.test(key) ? `${where} contains prohibited credential-shaped field "${key}"` : visit(item as Json)).find((error): error is string => error !== null) ?? null : null
  return visit(v)
}
const cleanProjectLocal = (v: unknown, where: string): string | null => {
  if (!record(v) || !json(v)) return `${where} must be a JSON object`
  const visit = (value: Json): string | null => Array.isArray(value) ? value.map(visit).find((x): x is string => x !== null) ?? null : record(value) ? Object.entries(value).map(([key, item]) => {
    if (key === "credentialVariable") return typeof item === "string" && /^[A-Z_][A-Z0-9_]*$/.test(item) ? null : `${where} has unsafe credentialVariable`
    if (/^(apiKey|credentialValue|token|authorization|password|secret)$/i.test(key)) return `${where} contains credential value field "${key}"`
    return visit(item as Json)
  }).find((x): x is string => x !== null) ?? null : null
  return visit(v)
}

export type GlobalPolicyV2 = {
  schemaVersion: typeof GLOBAL_POLICY_V2
  declarationCaps: { maxAgentRunsPerProject: number; maxLifetimeModelProviderRequestsPerProject: number; maxLeadToWorkerTurnsPerProject?: number }
  phaseDefaults?: { agentRuns: number; leadToWorkerTurns: number; phaseAttempts: number }
  ownerExecutionDefaults: { defaultMaxAttemptsPerTask: number; maxWorkerConcurrency: number; maxSpawnDepth: number }
  sourceMetadata: { updatedAt: string }; routingPolicy: JsonObject
  paidBudget: 0
  billingPolicy: JsonObject
  authorityPolicy: JsonObject
  providerMetadata: JsonObject
  cooldownObservations: JsonObject
  legacyMetadata: JsonObject
}
const globalKeys = ["schemaVersion", "declarationCaps", "phaseDefaults", "ownerExecutionDefaults", "sourceMetadata", "routingPolicy", "paidBudget", "billingPolicy", "authorityPolicy", "providerMetadata", "cooldownObservations", "legacyMetadata"]
export function validateGlobalPolicyV2(input: unknown): Check<GlobalPolicyV2> {
  if (!record(input)) return fail("global policy must be an object")
  if (input.schemaVersion !== GLOBAL_POLICY_V2) return fail(`unsupported global policy schemaVersion; expected ${GLOBAL_POLICY_V2}`)
  const unknown = exact(input, globalKeys, "global policy"); if (unknown) return fail(unknown)
  if (input.paidBudget !== 0) return fail("global paidBudget must be exactly 0")
  if (!record(input.declarationCaps)) return fail("declarationCaps must be an object")
  const caps = input.declarationCaps; const capUnknown = exact(caps, ["maxAgentRunsPerProject", "maxLifetimeModelProviderRequestsPerProject", "maxLeadToWorkerTurnsPerProject"], "declarationCaps"); if (capUnknown) return fail(capUnknown)
  if (!nonnegative(caps.maxAgentRunsPerProject) || !nonnegative(caps.maxLifetimeModelProviderRequestsPerProject)) return fail("declaration caps must be non-negative safe integers")
  if (caps.maxLeadToWorkerTurnsPerProject !== undefined && !nonnegative(caps.maxLeadToWorkerTurnsPerProject)) return fail("maxLeadToWorkerTurnsPerProject must be a non-negative safe integer")
  if (input.phaseDefaults !== undefined) { if (!record(input.phaseDefaults)) return fail("phaseDefaults must be an object"); const defaults = input.phaseDefaults; const defaultsUnknown = exact(defaults, ["agentRuns", "leadToWorkerTurns", "phaseAttempts"], "phaseDefaults"); if (defaultsUnknown || !nonnegative(defaults.agentRuns) || !nonnegative(defaults.leadToWorkerTurns) || !nonnegative(defaults.phaseAttempts)) return fail("invalid phase defaults") }
  if (!record(input.ownerExecutionDefaults) || exact(input.ownerExecutionDefaults, ["defaultMaxAttemptsPerTask", "maxWorkerConcurrency", "maxSpawnDepth"], "ownerExecutionDefaults") || !nonnegative(input.ownerExecutionDefaults.defaultMaxAttemptsPerTask) || !nonnegative(input.ownerExecutionDefaults.maxWorkerConcurrency) || !nonnegative(input.ownerExecutionDefaults.maxSpawnDepth) || input.ownerExecutionDefaults.maxWorkerConcurrency < 1 || !record(input.sourceMetadata) || typeof input.sourceMetadata.updatedAt !== "string") return fail("invalid owner execution defaults")
  for (const key of ["billingPolicy", "authorityPolicy", "routingPolicy", "providerMetadata", "cooldownObservations", "legacyMetadata"] as const) { const error = cleanMetadata(input[key], key); if (error) return fail(error) }
  return { ok: true, value: input as GlobalPolicyV2 }
}

export type ProjectStateV2 = {
  schemaVersion: typeof PROJECT_STATE_V2; projectId: string
  phase: string; activeUnit: Json | null; acceptedLine: string; lastUpdated: string
  lifetime: { agentRunCeiling: number; agentRunsUsed: number; paidSpendCeiling: 0; paidSpendUsed: 0 }
  /** Optional compatibility extension.  Once present it is monotonic and has named units. */
  requestCounters?: { lifetimeModelProviderRequests: number; jevRequests: number }
  accepted: { line: string; commit: string; evidenceRefs: string[] }
  providerObservations: JsonObject; bootstrap: JsonObject; historyReferences: JsonObject
  phasePlan: JsonObject
  phaseHistory: JsonObject[]
  tasks: JsonObject[]; results: JsonObject[]; pause: Json | null; inFlight: JsonObject[]
}
const projectKeys = ["schemaVersion", "projectId", "phase", "activeUnit", "acceptedLine", "lastUpdated", "lifetime", "requestCounters", "accepted", "providerObservations", "bootstrap", "historyReferences", "phasePlan", "phaseHistory", "tasks", "results", "pause", "inFlight"]
export function validateProjectStateV2(input: unknown): Check<ProjectStateV2> {
  if (!record(input)) return fail("project state must be an object")
  if (input.schemaVersion !== PROJECT_STATE_V2) return fail(`unsupported project state schemaVersion; expected ${PROJECT_STATE_V2}`)
  const unknown = exact(input, projectKeys, "project state"); if (unknown) return fail(unknown)
  if (typeof input.projectId !== "string" || !input.projectId || typeof input.phase !== "string" || typeof input.acceptedLine !== "string" || typeof input.lastUpdated !== "string" || (input.activeUnit !== null && !json(input.activeUnit))) return fail("project identity fields are invalid")
  if (!record(input.lifetime) || exact(input.lifetime, ["agentRunCeiling", "agentRunsUsed", "paidSpendCeiling", "paidSpendUsed"], "lifetime")) return fail("invalid lifetime fields")
  const life = input.lifetime; if (!nonnegative(life.agentRunCeiling) || !nonnegative(life.agentRunsUsed) || life.agentRunsUsed > life.agentRunCeiling || life.paidSpendCeiling !== 0 || life.paidSpendUsed !== 0) return fail("invalid lifetime counters or paid spend")
  if (input.requestCounters !== undefined) {
    if (!record(input.requestCounters) || exact(input.requestCounters, ["lifetimeModelProviderRequests", "jevRequests"], "requestCounters") || !nonnegative(input.requestCounters.lifetimeModelProviderRequests) || !nonnegative(input.requestCounters.jevRequests) || input.requestCounters.jevRequests > input.requestCounters.lifetimeModelProviderRequests) return fail("invalid named request counters")
  }
  if (!record(input.accepted) || exact(input.accepted, ["line", "commit", "evidenceRefs"], "accepted") || typeof input.accepted.line !== "string" || typeof input.accepted.commit !== "string" || !Array.isArray(input.accepted.evidenceRefs) || !input.accepted.evidenceRefs.every(x => typeof x === "string")) return fail("invalid accepted state")
  if (!Array.isArray(input.phaseHistory) || !input.phaseHistory.every(x => record(x) && json(x))) return fail("phaseHistory must contain JSON objects")
  if (!Array.isArray(input.tasks) || !Array.isArray(input.results) || !Array.isArray(input.inFlight) || !input.tasks.every(x => record(x) && json(x)) || !input.results.every(x => record(x) && json(x)) || !input.inFlight.every(x => record(x) && json(x))) return fail("tasks/results/inFlight must be JSON-object arrays")
  for (const key of ["bootstrap"] as const) { const error = cleanMetadata(input[key], key); if (error) return fail(error) }
  for (const key of ["providerObservations", "historyReferences"] as const) { const error = cleanProjectLocal(input[key], key); if (error) return fail(error) }
  const phasePlanError = cleanProjectPayload(input.phasePlan, "phasePlan"); if (phasePlanError) return fail(phasePlanError)
  return { ok: true, value: input as ProjectStateV2 }
}

export const stableJson = (value: unknown): string => JSON.stringify(sort(value), null, 2) + "\n"
const sort = (v: unknown): unknown => Array.isArray(v) ? v.map(sort) : record(v) ? Object.fromEntries(Object.keys(v).sort().map(k => [k, sort(v[k])])) : v
export const sha256 = (text: string): string => createHash("sha256").update(text).digest("hex")

/** Compatibility migration accepts only legacy v1 objects; V2 is normalized byte-stably. */
export function migrateGlobalPolicyV1(input: unknown): Check<GlobalPolicyV2> {
  if (record(input) && input.schemaVersion === GLOBAL_POLICY_V2) return validateGlobalPolicyV2(input)
  if (!record(input) || !(input.schemaVersion === 1 || input.schemaVersion === "1")) return fail("unsupported legacy global policy version")
  const topUnknown = exact(input, ["schemaVersion", "updatedAt", "ownerCeilings", "authority", "routingPolicy", "providers"], "legacy global policy"); if (topUnknown) return fail(topUnknown)
  if (typeof input.updatedAt !== "string" || !record(input.ownerCeilings) || exact(input.ownerCeilings, ["paidBudget", "maxCallsPerProject", "maxAgentRunsPerProject", "defaultMaxAttemptsPerTask", "maxWorkerConcurrency", "maxSpawnDepth"], "legacy ownerCeilings")) return fail("legacy ownerCeilings is malformed")
  const ceilings = input.ownerCeilings
  if (ceilings.paidBudget !== 0 || !nonnegative(ceilings.maxCallsPerProject) || !nonnegative(ceilings.maxAgentRunsPerProject) || !nonnegative(ceilings.defaultMaxAttemptsPerTask) || !nonnegative(ceilings.maxWorkerConcurrency) || !nonnegative(ceilings.maxSpawnDepth) || ceilings.maxWorkerConcurrency < 1 || !record(input.authority) || !record(input.routingPolicy) || !record(input.providers) || !json(input.authority) || !json(input.routingPolicy) || !json(input.providers)) return fail("legacy ownerCeilings has invalid limits")
  const pick = (keys: string[]): JsonObject => Object.fromEntries(keys.filter(k => input[k] !== undefined).map(k => [k, input[k] as Json]))
  const caps: GlobalPolicyV2["declarationCaps"] = { maxAgentRunsPerProject: ceilings.maxAgentRunsPerProject, maxLifetimeModelProviderRequestsPerProject: ceilings.maxCallsPerProject }
  const migrated: GlobalPolicyV2 = { schemaVersion: GLOBAL_POLICY_V2, declarationCaps: caps, ownerExecutionDefaults: { defaultMaxAttemptsPerTask: ceilings.defaultMaxAttemptsPerTask, maxWorkerConcurrency: ceilings.maxWorkerConcurrency, maxSpawnDepth: ceilings.maxSpawnDepth }, sourceMetadata: { updatedAt: input.updatedAt }, routingPolicy: input.routingPolicy as JsonObject, paidBudget: 0, billingPolicy: {}, authorityPolicy: input.authority as JsonObject, providerMetadata: input.providers as JsonObject, cooldownObservations: {}, legacyMetadata: {} }
  return validateGlobalPolicyV2(migrated)
}

export function migrateProjectStateV1(input: unknown): Check<ProjectStateV2> {
  if (record(input) && input.schemaVersion === PROJECT_STATE_V2) return validateProjectStateV2(input)
  if (!record(input) || input.schemaVersion !== "bootstrap-v1") return fail("unsupported legacy project state version")
  const legacyUnknown = exact(input, ["schemaVersion", "projectId", "phase", "activeUnit", "acceptedLine", "lifetime", "phasePlan", "tasks", "inFlight", "providerStates", "bootstrap", "runtime", "jevConfiguration", "pause", "phase2PolicyMigration", "lastUpdated"], "bootstrap project state"); if (legacyUnknown) return fail(legacyUnknown)
  if (typeof input.projectId !== "string" || typeof input.phase !== "string" || typeof input.acceptedLine !== "string" || typeof input.lastUpdated !== "string" || (input.activeUnit !== null && !json(input.activeUnit)) || !record(input.lifetime) || exact(input.lifetime, ["agentRunsUsed", "agentRunCeiling", "paidSpendCeiling", "paidSpendUsed"], "bootstrap lifetime") || !nonnegative(input.lifetime.agentRunsUsed) || !nonnegative(input.lifetime.agentRunCeiling) || input.lifetime.agentRunsUsed > input.lifetime.agentRunCeiling || input.lifetime.paidSpendCeiling !== 0 || input.lifetime.paidSpendUsed !== 0 || !record(input.phasePlan) || !json(input.phasePlan) || !Array.isArray(input.tasks) || !input.tasks.every(x => record(x) && json(x)) || !Array.isArray(input.inFlight) || !input.inFlight.every(x => record(x) && json(x)) || !record(input.runtime)) return fail("bootstrap project state is malformed")
  const runtime = input.runtime
  if (typeof runtime.acceptedCommit !== "string") return fail("bootstrap runtime.acceptedCommit is required")
  const phasePlan = input.phasePlan as JsonObject
  const allocation = record(phasePlan.allocation) ? phasePlan.allocation : {}; const counters = record(phasePlan.counters) ? phasePlan.counters : {}
  if (typeof phasePlan.phaseId !== "string" || typeof phasePlan.status !== "string" || !nonnegative(allocation.agentRuns) || !nonnegative(allocation.leadToWorkerTurns) || !nonnegative(allocation.phaseAttempts) || !nonnegative(allocation.concurrency) || allocation.concurrency < 1 || allocation.paidSpend !== 0 || !nonnegative(counters.agentRuns) || !nonnegative(counters.leadToWorkerTurns) || !nonnegative(counters.phaseAttempts) || !nonnegative(counters.activeWorkers) || counters.agentRuns > allocation.agentRuns || counters.leadToWorkerTurns > allocation.leadToWorkerTurns || counters.phaseAttempts > allocation.phaseAttempts || counters.activeWorkers > allocation.concurrency) return fail("bootstrap phasePlan is malformed")
  const taskEvidence = input.tasks.flatMap(task => record(task) && Array.isArray(task.evidence) ? task.evidence.filter((x): x is string => typeof x === "string") : [])
  const runtimeEvidence = [runtime.phaseCompletionEvidence, runtime.preflightEvidence].filter((x): x is string => typeof x === "string")
  const acceptedEvidence = [...taskEvidence, ...runtimeEvidence]
  const migrated: ProjectStateV2 = { schemaVersion: PROJECT_STATE_V2, projectId: input.projectId, phase: input.phase, activeUnit: input.activeUnit as Json ?? null, acceptedLine: input.acceptedLine, lastUpdated: input.lastUpdated, lifetime: { agentRunCeiling: input.lifetime.agentRunCeiling, agentRunsUsed: input.lifetime.agentRunsUsed, paidSpendCeiling: 0, paidSpendUsed: 0 }, requestCounters: { lifetimeModelProviderRequests: 0, jevRequests: 0 }, accepted: { line: input.acceptedLine, commit: runtime.acceptedCommit, evidenceRefs: acceptedEvidence }, providerObservations: record(input.providerStates) && json(input.providerStates) ? input.providerStates as JsonObject : {}, bootstrap: record(input.bootstrap) && json(input.bootstrap) ? input.bootstrap as JsonObject : {}, historyReferences: { phase2PolicyMigration: input.phase2PolicyMigration as Json ?? null, jevConfiguration: input.jevConfiguration as Json ?? null, runtime: runtime as JsonObject }, phasePlan, phaseHistory: [{ phaseId: "phase-1", immutable: true, evidenceRefs: acceptedEvidence, acceptedCommit: runtime.acceptedCommit }], tasks: input.tasks as JsonObject[], results: input.tasks.flatMap(task => record(task) && typeof task.taskId === "string" && task.result !== undefined && json(task.result) ? [{ taskId: task.taskId, result: task.result } satisfies JsonObject] : []), pause: input.pause !== undefined && json(input.pause) ? input.pause : null, inFlight: input.inFlight as JsonObject[] }
  return validateProjectStateV2(migrated)
}

export type MigrationRequest = { path: string; mode: "dry-run" | "apply"; expectedSha256: string; expectedSchemaVersion: 1 | "1" | "bootstrap-v1"; expectedMode: number; simulateInterruption?: boolean; beforeFinalRename?: () => Promise<void> }
export type MigrationReceipt = { path: string; mode: "dry-run" | "apply"; beforeSha256: string; afterSha256: string; backupPath: string | null; backupSha256: string | null; originalMode: number; rollback: { sourceSha256: string; backupSha256: string } }
const regular = async (path: string): Promise<{ mode: number; dev: number; ino: number }> => { const s = await lstat(path); if (!s.isFile() || s.isSymbolicLink()) throw new Error("policy source must be a non-symlink regular file"); return { mode: s.mode & 0o777, dev: s.dev, ino: s.ino } }
const sameIdentity = (a: { dev: number; ino: number }, b: { dev: number; ino: number }) => a.dev === b.dev && a.ino === b.ino
/** Explicit path only. A failure before rename leaves `path` bytes unchanged. */
export async function migrateGlobalPolicyFile(request: MigrationRequest): Promise<MigrationReceipt> {
  return migrateFile(request, migrateGlobalPolicyV1, "policy source")
}
/** Same explicit-path primitive for Lead-only canonical project-state migration. */
export async function migrateProjectStateFile(request: MigrationRequest): Promise<MigrationReceipt> {
  return migrateFile(request, migrateProjectStateV1, "project-state source")
}
async function migrateFile(request: MigrationRequest, migrate: (input: unknown) => Check<Json>, label: string): Promise<MigrationReceipt> {
  if (!request.path || request.expectedMode !== 0o600) throw new Error("explicit path and expected mode 0600 are required")
  const beforeStat = await regular(request.path); if (beforeStat.mode !== request.expectedMode) throw new Error("source mode drift")
  const before = await readFile(request.path, "utf8"); const beforeHash = sha256(before); if (beforeHash !== request.expectedSha256) throw new Error("source hash drift")
  let parsed: unknown; try { parsed = JSON.parse(before) } catch { throw new Error("source is not valid JSON") }
  if (!record(parsed) || parsed.schemaVersion !== request.expectedSchemaVersion) throw new Error("source schema drift")
  const migrated = migrate(parsed); if (!migrated.ok) throw new Error(migrated.errors.join("; "))
  const output = stableJson(migrated.value); const afterHash = sha256(output)
  if (request.mode === "dry-run") return { path: request.path, mode: "dry-run", beforeSha256: beforeHash, afterSha256: afterHash, backupPath: null, backupSha256: null, originalMode: beforeStat.mode, rollback: { sourceSha256: beforeHash, backupSha256: beforeHash } }
  if (request.simulateInterruption) throw new Error("simulated interruption before rename")
  const recheck = await readFile(request.path, "utf8"); const stageStat = await regular(request.path); if (sha256(recheck) !== beforeHash || stageStat.mode !== beforeStat.mode || !sameIdentity(stageStat, beforeStat)) throw new Error("source drift before rename")
  const dir = dirname(request.path), base = basename(request.path), backupPath = join(dir, `.${base}.${beforeHash}.backup`), tempPath = join(dir, `.${base}.${afterHash}.tmp`)
  try {
    await writeFile(backupPath, before, { encoding: "utf8", flag: "wx", mode: beforeStat.mode }); await chmod(backupPath, beforeStat.mode)
    if (sha256(await readFile(backupPath, "utf8")) !== beforeHash) throw new Error("backup hash mismatch")
    await writeFile(tempPath, output, { encoding: "utf8", flag: "wx", mode: beforeStat.mode }); await chmod(tempPath, beforeStat.mode)
    if (sha256(await readFile(tempPath, "utf8")) !== afterHash) throw new Error("temporary output hash mismatch")
    await request.beforeFinalRename?.()
    const lastBytes = await readFile(request.path, "utf8")
    const finalStat = await regular(request.path)
    if (sha256(lastBytes) !== beforeHash || finalStat.mode !== beforeStat.mode || !sameIdentity(finalStat, beforeStat)) throw new Error(`${label} drift before final rename`)
    await rename(tempPath, request.path)
  } catch (error) { try { await unlink(tempPath) } catch {} throw error }
  if (sha256(await readFile(request.path, "utf8")) !== afterHash || (await regular(request.path)).mode !== beforeStat.mode) throw new Error("after-write validation failed")
  return { path: request.path, mode: "apply", beforeSha256: beforeHash, afterSha256: afterHash, backupPath, backupSha256: beforeHash, originalMode: beforeStat.mode, rollback: { sourceSha256: afterHash, backupSha256: beforeHash } }
}
export async function rollbackGlobalPolicyFile(receipt: MigrationReceipt): Promise<void> {
  if (receipt.mode !== "apply" || !receipt.backupPath) throw new Error("an apply receipt with backup is required")
  if (sha256(await readFile(receipt.path, "utf8")) !== receipt.afterSha256 || sha256(await readFile(receipt.backupPath, "utf8")) !== receipt.beforeSha256) throw new Error("rollback precondition drift")
  const temp = join(dirname(receipt.path), `.${basename(receipt.path)}.${receipt.beforeSha256}.rollback.tmp`)
  await writeFile(temp, await readFile(receipt.backupPath, "utf8"), { encoding: "utf8", flag: "wx", mode: receipt.originalMode }); await chmod(temp, receipt.originalMode); await rename(temp, receipt.path)
  if (sha256(await readFile(receipt.path, "utf8")) !== receipt.beforeSha256 || (await regular(receipt.path)).mode !== receipt.originalMode) throw new Error("rollback validation failed")
}
