import { appendFile, mkdir, open, readFile, rename, stat, unlink, writeFile } from "node:fs/promises"
import { dirname, join } from "node:path"
import { TimeoutError } from "./types.ts"
import type { Clock, JevFs } from "./types.ts"

export const nodeFs: JevFs = {
  readFile: (path) => readFile(path, "utf8"),
  writeFile: (path, data) => writeFile(path, data, { encoding: "utf8" }), rename,
  appendFile: (path, data) => appendFile(path, data, "utf8"),
  mkdir: async path => { await mkdir(path, { recursive: true }) },
  async createExclusive(path, data) { const handle = await open(path, "wx"); try { await handle.writeFile(data, "utf8") } finally { await handle.close() } },
  unlink,
  async exists(path) { try { await stat(path); return true } catch (error) { if (errorCode(error) === "ENOENT") return false; throw error } },
}
export const realClock: Clock = {
  now: () => new Date(), sleep: ms => new Promise(resolve => setTimeout(resolve, ms)),
  timeout(ms) { let handle: ReturnType<typeof setTimeout> | undefined; const promise = new Promise<never>((_, reject) => { handle = setTimeout(() => reject(new TimeoutError(ms)), ms) }); promise.catch(() => {}); return { promise, cancel: () => clearTimeout(handle) } },
}
export const errorCode = (error: unknown): string | undefined => typeof error === "object" && error !== null && "code" in error ? String((error as { code: unknown }).code) : undefined
export type ProjectPaths = { loopDir: string; statePath: string; eventsPath: string; lockPath: string; decisionPath(runId: string, decisionId: string): string }
export const projectPaths = (projectDir: string): ProjectPaths => { const loopDir = join(projectDir, ".loop"); return { loopDir, statePath: join(loopDir, "state.json"), eventsPath: join(loopDir, "events.jsonl"), lockPath: join(loopDir, "jev.lock"), decisionPath: (runId, decisionId) => join(loopDir, "runs", runId, "decisions", `${decisionId}.json`) } }
let nonce = 0
export async function writeJsonAtomic(fs: JevFs, path: string, value: unknown, clock: Clock): Promise<void> { await fs.mkdir(dirname(path)); const temp = `${path}.${process.pid}.${clock.now().getTime()}.${++nonce}.tmp`; try { await fs.writeFile(temp, `${JSON.stringify(value, null, 2)}\n`); await fs.rename(temp, path) } catch (error) { await fs.unlink(temp).catch(() => {}); throw error } }
export const readJson = async (fs: JevFs, path: string): Promise<unknown> => JSON.parse(await fs.readFile(path))
export async function appendEvent(fs: JevFs, path: string, event: unknown): Promise<void> { await fs.mkdir(dirname(path)); await fs.appendFile(path, `${JSON.stringify(event)}\n`) }
export class LockError extends Error {}
export type LockOptions = { retries?: number; retryMs?: number }
/** Locks are never broken automatically. An interrupted holder fails closed until an operator inspects it. */
export async function withLock<T>(fs: JevFs, clock: Clock, lockPath: string, options: LockOptions, body: () => Promise<T>): Promise<T> {
  const retries = options.retries ?? 100, retryMs = options.retryMs ?? 25, token = `${process.pid}@${clock.now().toISOString()}#${++nonce}`
  await fs.mkdir(dirname(lockPath)); let held = false
  for (let attempt = 0; attempt <= retries && !held; attempt++) try { await fs.createExclusive(lockPath, token); held = true } catch (error) { if (errorCode(error) !== "EEXIST") throw new LockError(`cannot create lock ${lockPath}`); if (attempt < retries) await clock.sleep(retryMs) }
  if (!held) throw new LockError(`project lock ${lockPath} is held; refusing to proceed`)
  try { return await body() } finally { try { if (await fs.readFile(lockPath) === token) await fs.unlink(lockPath) } catch {} }
}
