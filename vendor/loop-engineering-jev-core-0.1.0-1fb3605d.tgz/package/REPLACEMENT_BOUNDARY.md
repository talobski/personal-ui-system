# Replacement boundary

After Phase 1 gate acceptance, this package is the sole shared authority for
the extracted public contract, packet admission, primitive acceptance,
composition, and audit sanitization. The bootstrap adapter remains read-only
historical bootstrap infrastructure until its separately admitted migration.

There is no sync-back workflow and no bidirectional maintenance. Changes here
must be independently admitted and accompanied by contract fixtures; changes
in the bootstrap source do not flow here automatically. This package excludes
transport, API-key access, Jev calls, persistence, policy loading, retries,
dispatch, and telemetry.
