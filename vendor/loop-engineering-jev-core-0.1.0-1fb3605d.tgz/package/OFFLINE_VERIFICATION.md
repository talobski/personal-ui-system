# Offline verification

The repository vendors only two already-local cached TypeScript 7.0.2 package
archives: the compiler and the required Darwin ARM64 executable package. Their
SHA-512 integrity values are pinned in `package-lock.json`; no global compiler,
another project's `node_modules`, or registry access is used.

From a fresh checkout with no `node_modules`, run:

```sh
npm ci --offline --ignore-scripts --cache .npm-cache
npm run verify:offline
npm run build
npm run verify:provenance
```

The ignored `.npm-cache` is workspace-local. The test runner is Node 22's
built-in test runner with type stripping; semantic checking is the locked local
TypeScript compiler in `node_modules/.bin/tsc`.

For the immutable Phase 4 package checkpoint, run `sh scripts/verify-package.sh`.
It verifies the source commit, package/dependency hashes and exact contents,
then performs a cache-isolated offline install, semantic check, tests, and build
from a newly unpacked copy of the tarball.
