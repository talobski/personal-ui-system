#!/bin/sh
set -eu

source_root=/Users/emmantalob/dev/personal-ui-system/tools/loop/jev
source_path_prefix=tools/loop/jev
expected_commit=dedf949702e9b869670cbb3bc344d4e1b220f4dd
extracted_root=.
expected_types_hash=308cb724802c561453130804b58ce56ddcb1aacd35b081786757b0274a6999dd

# Test-only inputs exercise fail-closed blob lookup without weakening production pins.
if [ "${PROVENANCE_TEST_MODE:-}" = 1 ]; then
  source_root=${PROVENANCE_TEST_SOURCE_ROOT:-$source_root}
  source_path_prefix=${PROVENANCE_TEST_PATH_PREFIX:-$source_path_prefix}
  expected_commit=${PROVENANCE_TEST_EXPECTED_COMMIT:-$expected_commit}
  extracted_root=${PROVENANCE_TEST_EXTRACTED_ROOT:-$extracted_root}
  expected_types_hash=${PROVENANCE_TEST_TYPES_HASH:-$expected_types_hash}
fi

check() {
  expected=$1
  source_path=$2
  extracted=$3
  [ "$(git -C "$source_root" show "$expected_commit:$source_path" | shasum -a 256 | awk '{print $1}')" = "$expected" ]
  [ "$(shasum -a 256 "$extracted" | awk '{print $1}')" = "$expected" ]
  git -C "$source_root" show "$expected_commit:$source_path" | cmp -s - "$extracted"
}

check "$expected_types_hash" "$source_path_prefix/types.ts" "$extracted_root/src/types.ts"
check 35e977717ac26789442a3f9e19b4ebf60138a915fe23147eb2a3d9fb6b08f977 "$source_path_prefix/accept.ts" "$extracted_root/src/accept.ts"
check ad30f7887d4333a22b0c627a325382d74c4223f4380cfdfeb0c32197af18306e "$source_path_prefix/packet.ts" "$extracted_root/src/packet.ts"
check 0ee472426f9314c0c5b5f4a7e49a65ece19acd3329133e24d426b50c76db367a "$source_path_prefix/compose.ts" "$extracted_root/src/compose.ts"
printf '%s\n' 'provenance: pinned source and controlled extractions match'
