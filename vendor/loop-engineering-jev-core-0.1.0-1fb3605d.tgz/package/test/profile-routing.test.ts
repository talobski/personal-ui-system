import assert from "node:assert/strict"
import { readFile } from "node:fs/promises"
import { test } from "node:test"
import { CONFIDENCE_THRESHOLD } from "../src/accept.ts"
import { CLAUDE_WORKER_PROFILE, CODEX_WORKER_PROFILE, PROHIBITED_OPERATIONS, acceptRouteAnswer, admitProposedWorker, admitRoute, capacityPrior, composeRouteProfilePacket, createCapacityRoutingPlan, createEligibleProfilePlan, createProfileApplicationPlan, createSyntheticNegativeReceipts, decideFanOut, reconcileWorkerProfile, selectMockRoute, validateNegativeAdmissionFixture, validateProfileApplyReceipt, validateWorkerProfile } from "../src/profile-routing.ts"
import { validatePacket } from "../src/packet.ts"
import { buildComposerRegistry } from "../src/compose.ts"

const now = "2026-09-21T12:00:00.000Z"
const receipts = (profile = CODEX_WORKER_PROFILE) => createSyntheticNegativeReceipts(profile)
const state = (profile: typeof CODEX_WORKER_PROFILE | typeof CLAUDE_WORKER_PROFILE, comparison: "CODEX_GT_CLAUDE" | "CLAUDE_GT_CODEX" | "UNKNOWN" = "CODEX_GT_CLAUDE", observedAt = "2026-09-21T11:30:00.000Z") => ({ profile, health: "AVAILABLE" as const, availableCapabilities: ["filesystem", "shell", "typescript"], billingEligible: true, capacity: { source: "owner-supplied", observedAt, maxAgeMs: 3_600_000, comparison, evidence: "owner comparison only; no numeric quota" } })

test("P3-01 exact supplied declarations, JSON artifacts, and strict profile boundaries", async () => {
  for (const [profile, file] of [[CODEX_WORKER_PROFILE, "profiles/codex-worker.profile.json"], [CLAUDE_WORKER_PROFILE, "profiles/claude-worker.profile.json"]] as const) {
    assert.deepEqual(JSON.parse(await readFile(file, "utf8")), profile, "JSON artifact must exactly equal runtime declaration")
    assert.ok(validateWorkerProfile(profile).ok)
    for (const bad of [{ ...profile, unknown: true }, { ...profile, model: "unsupported" }, { ...profile, profileKind: "lead" }, { ...profile, workspaceIsolation: "host" }, { ...profile, paseo: { ...profile.paseo, requestedModeId: "manual" } }, { ...profile, paseo: { ...profile.paseo, allowedEffectiveModeIds: ["auto-review"] } }, { ...profile, paseo: { ...profile.paseo, thinkingOptionId: "high" } }, { ...profile, paseo: { ...profile.paseo, features: { paid: true } } }, { ...profile, billing: { class: "paid", paid: true } }, { ...profile, notes: ["Codex permanent primary"] }, { ...profile, permissionEnvelope: { ...profile.permissionEnvelope, network: true } }]) assert.equal(validateWorkerProfile(bad).ok, false)
  }
  assert.equal(CODEX_WORKER_PROFILE.id, "loop_worker_codex_standard")
  assert.deepEqual(CODEX_WORKER_PROFILE.paseo.allowedEffectiveModeIds, ["auto", "auto-review"])
  assert.deepEqual(CLAUDE_WORKER_PROFILE.paseo.allowedEffectiveModeIds, ["auto"])
})

test("P3-02 every synthetic denial receipt is bound and each mutation fails closed", () => {
  for (const profile of [CODEX_WORKER_PROFILE, CLAUDE_WORKER_PROFILE]) {
    const fixture = receipts(profile)
    assert.ok(validateNegativeAdmissionFixture(fixture, profile).ok)
    for (const operation of PROHIBITED_OPERATIONS) {
      const index = fixture.receipts.findIndex(receipt => receipt.operation === operation)
      const changed = structuredClone(fixture)
      changed.receipts[index]!.result = "ALLOWED" as never
      assert.equal(validateNegativeAdmissionFixture(changed, profile).ok, false, operation)
      assert.equal(reconcileWorkerProfile(profile, { ...state(profile), negativeFixture: changed }, now).ok, false, `${operation} blocks reconciliation`)
      assert.equal(createEligibleProfilePlan(profile, { ...state(profile), negativeFixture: changed }, null, "registry", "registry-after", "candidate", now).ok, false, `${operation} blocks planning`)
    }
    assert.equal(validateNegativeAdmissionFixture({ ...fixture, profileHash: "wrong" }, profile).ok, false)
    assert.equal(validateNegativeAdmissionFixture({ ...fixture, receipts: fixture.receipts.slice(1) }, profile).ok, false)
    const duplicate = structuredClone(fixture); duplicate.receipts[1]!.operation = duplicate.receipts[0]!.operation
    assert.equal(validateNegativeAdmissionFixture(duplicate, profile).ok, false)
    const effect = structuredClone(fixture); effect.receipts[0]!.observedNoEffect.afterSnapshotHash = "changed"
    assert.equal(validateNegativeAdmissionFixture(effect, profile).ok, false)
  }
})

test("P3-03 reconciliation and pure exact plans are reversible and receipt-bound", () => {
  const codexFacts = state(CODEX_WORKER_PROFILE)
  assert.ok(reconcileWorkerProfile(CODEX_WORKER_PROFILE, { ...codexFacts, negativeFixture: receipts() }, now).ok, "supplied Codex snapshot reconciles")
  assert.equal(reconcileWorkerProfile(CODEX_WORKER_PROFILE, { ...codexFacts, profile: { ...CODEX_WORKER_PROFILE, model: "drift" }, negativeFixture: receipts() }, now).ok, false)
  const noop = createEligibleProfilePlan(CODEX_WORKER_PROFILE, { ...codexFacts, negativeFixture: receipts() }, CODEX_WORKER_PROFILE, "registry-codex", "registry-codex-after", "candidate-sha", now, "protected-sha")
  assert.ok(noop.ok); if (!noop.ok) return
  assert.equal(noop.value.action, "NOOP")
  const claudeFacts = state(CLAUDE_WORKER_PROFILE, "CLAUDE_GT_CODEX")
  assert.ok(admitProposedWorker(CLAUDE_WORKER_PROFILE, { ...claudeFacts, negativeFixture: receipts(CLAUDE_WORKER_PROFILE) }, now).ok)
  const create = createEligibleProfilePlan(CLAUDE_WORKER_PROFILE, { ...claudeFacts, negativeFixture: receipts(CLAUDE_WORKER_PROFILE) }, null, "registry-claude-absent", "registry-claude-created", "candidate-sha", now, "protected-sha")
  assert.ok(create.ok); if (!create.ok) return
  assert.equal(create.value.action, "CREATE"); assert.equal(create.value.expectedPriorProfile, null); assert.equal(create.value.activation, false); assert.equal(create.value.leadOnly, true)
  const update = createProfileApplicationPlan(CODEX_WORKER_PROFILE, { ...CODEX_WORKER_PROFILE, notes: ["repository declaration only", "bounded permission envelope", "staged declaration delta"] }, "registry-before", "registry-after", "candidate-sha", "protected-sha")
  assert.ok(update.ok); if (!update.ok) return
  assert.equal(update.value.action, "UPDATE")
  const eligibleUpdate = createEligibleProfilePlan(CODEX_WORKER_PROFILE, { ...codexFacts, negativeFixture: receipts() }, update.value.expectedPriorProfile, "registry-before", "registry-after", "candidate-sha", now, "protected-sha")
  assert.ok(eligibleUpdate.ok); if (eligibleUpdate.ok) assert.equal(eligibleUpdate.value.action, "UPDATE")
  const receiptFor = (plan: typeof create.value) => ({ actionId: plan.actionId, action: plan.action, candidateCommit: plan.candidateCommit, protectedVerificationCommit: plan.protectedVerificationCommit, profileId: plan.targetProfile.id, targetHash: plan.targetHash, beforeSnapshotHash: plan.registrySnapshotHash, afterProfileHash: plan.targetHash, afterSnapshotHash: plan.expectedAfterSnapshotHash, backupHash: plan.rollback.backupHash, rollbackVerified: true })
  for (const plan of [noop.value, create.value, update.value]) assert.ok(validateProfileApplyReceipt(plan, receiptFor(plan)).ok, `${plan.action} exact receipt passes`)
  const receipt = receiptFor(create.value)
  for (const changed of [
    { ...receipt, protectedVerificationCommit: "other-protected-sha" },
    { ...receipt, afterSnapshotHash: "arbitrary-nonempty-after-snapshot" },
    { ...receipt, targetHash: "other-target-hash" },
    { ...receipt, afterProfileHash: "other-after-profile-hash" },
    { ...receipt, candidateCommit: "other-candidate-sha" },
    { ...receipt, beforeSnapshotHash: "other-before-snapshot" },
    { ...receipt, backupHash: "other-backup-hash" },
    { ...receipt, rollbackVerified: false },
    { ...receipt, action: "UPDATE" as const },
    { ...receipt, actionId: "other-action-id" },
    { ...receipt, profileId: "other-profile-id" },
  ]) assert.equal(validateProfileApplyReceipt(create.value, changed).ok, false)
  assert.equal(createEligibleProfilePlan(CLAUDE_WORKER_PROFILE, { ...claudeFacts, negativeFixture: { ...receipts(CLAUDE_WORKER_PROFILE), receipts: receipts(CLAUDE_WORKER_PROFILE).receipts.slice(1) } }, null, "registry", "registry-after", "candidate", now).ok, false)
})

test("P3-04 health, capability, billing and capacity remain distinct", () => {
  assert.equal(capacityPrior("codex", state(CODEX_WORKER_PROFILE).capacity, now), "favored")
  assert.equal(capacityPrior("claude", state(CLAUDE_WORKER_PROFILE, "CLAUDE_GT_CODEX").capacity, now), "favored")
  assert.equal(capacityPrior("codex", state(CODEX_WORKER_PROFILE, "UNKNOWN").capacity, now), "neutral")
  assert.equal(capacityPrior("codex", state(CODEX_WORKER_PROFILE, "CODEX_GT_CLAUDE", "2026-09-21T09:00:00.000Z").capacity, now), "neutral")
  assert.equal(capacityPrior("codex", state(CODEX_WORKER_PROFILE, "CODEX_GT_CLAUDE", "2026-09-21T13:00:00.000Z").capacity, now), "neutral")
  assert.equal(capacityPrior("codex", { ...state(CODEX_WORKER_PROFILE).capacity, evidence: "premium quota=unlimited" }, now), "neutral")
  assert.equal(admitRoute({ ...state(CODEX_WORKER_PROFILE), health: "UNKNOWN" }, now).ok, false)
  assert.equal(admitRoute({ ...state(CODEX_WORKER_PROFILE), billingEligible: false }, now).ok, false)
  assert.equal(admitRoute({ ...state(CODEX_WORKER_PROFILE), availableCapabilities: ["filesystem"] }, now).ok, false)
})

test("P3-05 canonical Choice acceptance gates focused Choice + Score packet", () => {
  const codex = admitRoute(state(CODEX_WORKER_PROFILE), now, "claude")
  const claude = admitRoute(state(CLAUDE_WORKER_PROFILE), now, "codex")
  assert.ok(codex.ok); assert.ok(claude.ok); if (!codex.ok || !claude.ok) return
  const packet = composeRouteProfilePacket([codex.value, claude.value], "p3-run", "route-1")
  assert.ok(packet.ok); if (!packet.ok) return
  assert.ok(validatePacket(packet.value, { allowsBillingClass: name => name === "included" }, buildComposerRegistry()).ok)
  assert.equal(packet.value.questions[0]?.type, "choice"); assert.equal(packet.value.questions[1]?.type, "score")
  const valid = { type: "choice", choice: claude.value.id, confidence: 0.5, probabilities: { [codex.value.id]: 0.5, [claude.value.id]: 0.5 } }
  const accepted = acceptRouteAnswer(packet.value, valid); assert.ok(accepted.ok); if (accepted.ok) assert.ok((packet.value.state.admittedRouteIds as string[]).includes(accepted.value))
  assert.equal(acceptRouteAnswer(packet.value, { ...valid, confidence: 0.49 }).ok, false)
  assert.equal(acceptRouteAnswer(packet.value, { ...valid, choice: "not-offered", probabilities: { "not-offered": 1 } }).ok, false)
  assert.equal(CONFIDENCE_THRESHOLD, 0.5)
})

test("P3-06 both families may win softly; P3-07 preserves proportional fan-out", () => {
  const codex = admitRoute(state(CODEX_WORKER_PROFILE), now); const claude = admitRoute(state(CLAUDE_WORKER_PROFILE), now)
  assert.ok(codex.ok); assert.ok(claude.ok); if (!codex.ok || !claude.ok) return
  const codexWins = selectMockRoute([codex.value, claude.value], { [codex.value.id]: 9, [claude.value.id]: 2 })
  const claudeWins = selectMockRoute([codex.value, claude.value], { [codex.value.id]: 2, [claude.value.id]: 9 })
  assert.ok(codexWins.ok); assert.ok(claudeWins.ok)
  if (!codexWins.ok || !claudeWins.ok) return
  assert.equal(codexWins.value, codex.value.id)
  assert.equal(claudeWins.value, claude.value.id)
  assert.equal(decideFanOut({ duplicate: false, independentValue: false, budgetAvailable: true, concurrencyAvailable: true, permissionCompatible: true, billingEligible: true, expectedValue: 1 }), "SINGLE_WORKER")
  assert.equal(decideFanOut({ duplicate: true, independentValue: true, budgetAvailable: true, concurrencyAvailable: true, permissionCompatible: true, billingEligible: true, expectedValue: 1 }), "SINGLE_WORKER")
  assert.equal(decideFanOut({ duplicate: false, independentValue: true, budgetAvailable: true, concurrencyAvailable: true, permissionCompatible: true, billingEligible: true, expectedValue: 1 }), "OFFER_SECOND_WORKER")
  const plan = createCapacityRoutingPlan("candidate-sha", "policy-before", { [CODEX_WORKER_PROFILE.id]: "live-codex", [CLAUDE_WORKER_PROFILE.id]: "live-claude" })
  assert.equal(plan.activation, false); assert.equal(plan.leadOnly, true); assert.equal(plan.noPermanentPrimary, true); assert.equal(plan.claudeActiveSecondary, true)
})
