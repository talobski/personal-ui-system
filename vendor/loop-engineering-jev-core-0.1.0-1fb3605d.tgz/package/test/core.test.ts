import assert from "node:assert/strict"
import { test } from "node:test"
import { acceptAnswer, acceptBatch, CONFIDENCE_THRESHOLD } from "../src/accept.ts"
import { AUDIT_SCHEMA_VERSION, projectAudit } from "../src/audit.ts"
import { buildComposerRegistry } from "../src/compose.ts"
import { digestQuestions, validatePacket } from "../src/packet.ts"
import { REDACTED, redactString, sanitize } from "../src/sanitize.ts"
import { PACKET_SCHEMA_VERSION } from "../src/types.ts"
import { choice, noul, packet, score } from "./contract.fixture.ts"

const policy = { allowsBillingClass: (name: string) => name === "included" }
const registry = buildComposerRegistry()
const freshPacket = (): Record<string, unknown> => structuredClone(packet) as unknown as Record<string, unknown>
const check = (value: unknown) => validatePacket(value, policy, registry)

test("canonical public fixture admits without narrowing", () => {
  const input = freshPacket()
  input.admission = { ...(input.admission as object), questionsDigest: digestQuestions("NEXT_ACTION", [choice]) }
  const result = check(input)
  assert.ok(result.ok)
  assert.equal(result.packet.fallback?.output, "WAIT")
})

test("fallback is admitted before evaluation and invalid declarations fail closed", () => {
  const invalidOutput = freshPacket()
  invalidOutput.admission = { ...(invalidOutput.admission as object), questionsDigest: digestQuestions("NEXT_ACTION", [choice]) }
  invalidOutput.fallback = { id: "fallback", output: "COMPLETE" }
  const noChoice = freshPacket()
  noChoice.contract = "HUMAN_INTERRUPT"
  noChoice.questions = [noul]
  noChoice.composition = { id: "direct-noul", version: "1" }
  noChoice.fallback = { id: "fallback", output: "WAIT" }
  noChoice.admission = { ...(noChoice.admission as object), questionsDigest: digestQuestions("HUMAN_INTERRUPT", [noul]) }
  for (const candidate of [invalidOutput, noChoice, { ...freshPacket(), fallback: { id: "fallback", output: 9 } }]) {
    const result = check(candidate)
    assert.equal(result.ok, false)
    if (!result.ok) assert.ok(result.reason.code === "packet.inconsistent" || result.reason.code === "packet.malformed")
  }
})

test("Choice, Score, Noul and batch use fixed canonical acceptance", () => {
  assert.equal(CONFIDENCE_THRESHOLD, 0.5)
  assert.equal(acceptAnswer(choice, { type: "choice", choice: "WAIT", confidence: 0.5, probabilities: { WAIT: 0.5, VERIFY: 0.5 } }).ok, true)
  assert.equal(acceptAnswer(choice, { type: "choice", choice: "WAIT", confidence: 0.49, probabilities: { WAIT: 1 } }).ok, false)
  assert.equal(acceptAnswer(score, { type: "score", score: 1, confidence: 0.5, legend: { 0: "low", 1: "high" }, probabilities: { 0: 0.2, 1: 0.8 } }).ok, true)
  assert.equal(acceptAnswer(noul, { type: "noul", noul: 0.5 }).ok, false)
  const batch = acceptBatch([choice, score, noul], { next: { type: "choice", choice: "WAIT", confidence: 1, probabilities: { WAIT: 1 } }, score: { type: "score", score: 1, confidence: 1, legend: { 0: "low", 1: "high" }, probabilities: { 0: 0, 1: 1 } }, human: { type: "noul", noul: 0.9 } })
  assert.equal(batch.usable, true)
})

test("redacts compound identifiers and synthetic credential-shaped assignment material", () => {
  const input = { camelCaseToken: "synthetic-a", api_key: "synthetic-b", "authorization-header": "synthetic-c", tokenBudget: 4, contract: "apiKey=synthetic-d", state: "clientSecret: synthetic-e", questions: "Authorization=Bearer syntheticmaterial", answers: "basic syntheticmaterial", fallback: "credential=synthetic-f", reason: "accessToken=synthetic-g", url: "https://user:synthetic-pass@example.invalid/a" }
  const result = sanitize(input)
  assert.ok(result.ok)
  const text = JSON.stringify(result.value)
  for (const fragment of ["synthetic-a", "synthetic-b", "synthetic-c", "synthetic-d", "synthetic-e", "synthetic-f", "synthetic-g", "synthetic-pass"]) assert.equal(text.includes(fragment), false)
  assert.equal((result.value as Record<string, unknown>).tokenBudget, 4)
  assert.ok(text.includes(REDACTED))
  assert.equal(redactString("apiKey=synthetic-value tokenBudget=12").includes("synthetic-value"), false)
})

test("redacts short and long canonical Bearer and Basic authorization forms", () => {
  const fixtures = ["Bearer abc", "Basic xyz", "Bearer synthetic-long-material", "Basic synthetic-long-material"]
  for (const fixture of fixtures) {
    const redacted = redactString(fixture)
    assert.equal(redacted.includes(fixture.slice(fixture.indexOf(" ") + 1)), false)
    assert.equal(redacted, `Bearer ${REDACTED}`)
  }
})

test("typed audit projection preserves decision fields and removes synthetic material", () => {
  const auditPacket = structuredClone(packet)
  auditPacket.contract = "apiKey=synthetic-contract-material"
  auditPacket.state = { camelCaseToken: "synthetic-state-material", contract: "safe-contract-field" }
  auditPacket.questions[0] = {
    ...choice,
    instructions: "authorization-header: Bearer synthetic-question-material",
    options: [{ id: "WAIT", description: "https://demo-user:synthetic-url-material@example.invalid/path" }, { id: "VERIFY", description: "Verify." }],
  }
  auditPacket.fallback = { id: "fallback", output: "credential=synthetic-fallback-material" }
  const auditOutcome = {
    ...structuredClone(packet as typeof packet),
    accepted: false,
    status: "failed" as const,
    runId: "run",
    decisionId: "decision",
    contract: "api_key=synthetic-outcome-contract",
    answers: { next: { type: "choice" as const, choice: "Basic synthetic-answer-material", confidence: 1, probabilities: { WAIT: 1 } } },
    fallback: { id: "fallback", output: "access-token=synthetic-outcome-fallback" },
    reason: { code: "failed.network" as const, message: "authorizationLikeKey=synthetic-reason-material" },
    composition: { id: "snake_case_secret=synthetic-composition-material", version: "1" },
    output: null,
    pause: null,
    decisionPath: "runs/run/decision",
    attempt: 1,
    auditErrors: ["bearer=synthetic-error-material"],
  }
  const projection = projectAudit(auditPacket, auditOutcome)
  assert.ok(projection.ok)
  const view = projection.value as Record<string, unknown>
  assert.equal(view.schemaVersion, AUDIT_SCHEMA_VERSION)
  assert.equal(view.projectId, "project")
  assert.equal(view.runId, "run")
  assert.equal(view.decisionId, "decision")
  const outcomeView = view.outcome as Record<string, unknown>
  assert.equal(outcomeView.status, "failed")
  for (const field of ["state", "questions", "declaredFallback"]) assert.ok(field in view)
  for (const field of ["answers", "fallback", "reason", "composition", "status"]) assert.ok(field in outcomeView)
  const text = JSON.stringify(view)
  for (const leaked of ["synthetic-contract-material", "synthetic-state-material", "synthetic-question-material", "synthetic-url-material", "synthetic-fallback-material", "synthetic-answer-material", "synthetic-outcome-fallback", "synthetic-reason-material", "synthetic-composition-material", "synthetic-error-material"]) assert.equal(text.includes(leaked), false)
})

test("packet schema version remains exact", () => assert.equal(PACKET_SCHEMA_VERSION, "loop-jev-admission/1"))
