import assert from "node:assert/strict"
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises"
import { join } from "node:path"
import { test } from "node:test"
import { runDecision, API_KEY_VARIABLE } from "../src/adapter.ts"
import { digestQuestions } from "../src/packet.ts"
import { nodeFs } from "../src/store.ts"
import type { FetchLike } from "../src/types.ts"

const policy = { schemaVersion: "loop-global-policy/2", declarationCaps: { maxAgentRunsPerProject: 23, maxLifetimeModelProviderRequestsPerProject: 80 }, ownerExecutionDefaults: { defaultMaxAttemptsPerTask: 4, maxWorkerConcurrency: 1, maxSpawnDepth: 1 }, sourceMetadata: { updatedAt: "2026-09-22T00:00:00Z" }, routingPolicy: { billingClasses: { includedSubscription: true, temporaryCredit: false } }, paidBudget: 0, billingPolicy: {}, authorityPolicy: {}, providerMetadata: {}, cooldownObservations: {}, legacyMetadata: {} }
const question = { id: "next", type: "choice" as const, instructions: "choose", options: [{ id: "RESEARCH", description: "r" }, { id: "WAIT", description: "w" }] }
const packet = (id = "d1", billingClass = "included-subscription") => ({ schemaVersion: "loop-jev-admission/1", projectId: "runtime-test", runId: "r1", decisionId: id, contract: "NEXT_ACTION", composition: { id: "direct-choice", version: "1" }, admission: { gate: "test", questionsDigest: digestQuestions("NEXT_ACTION", [question]), authority: { billingClass, paidCapacity: false, permissionEscalation: false, verificationWaived: false, completionWaived: false, completionPreconditionsPassed: false } }, state: { nonSecret: true }, questions: [question] })
const state = (requests = 23, jev = 2) => ({ schemaVersion: "loop-project-state/2", projectId: "runtime-test", phase: "RUNNING", activeUnit: null, acceptedLine: "main", lastUpdated: "2026-09-22T00:00:00Z", lifetime: { agentRunCeiling: 23, agentRunsUsed: 19, paidSpendCeiling: 0, paidSpendUsed: 0 }, requestCounters: { lifetimeModelProviderRequests: requests, jevRequests: jev }, accepted: { line: "main", commit: "source", evidenceRefs: [] }, providerObservations: {}, bootstrap: {}, historyReferences: {}, phasePlan: {}, phaseHistory: [], tasks: [], results: [], pause: null, inFlight: [] })
async function fixture(requests = 23, jev = 2, policyOverride: unknown = policy) { const dir = await mkdtemp("./.runtime-test-"); await nodeFs.mkdir(join(dir, ".loop")); const policyPath = join(dir, "policy.json"); await writeFile(policyPath, JSON.stringify(policyOverride)); await writeFile(join(dir, ".loop", "state.json"), JSON.stringify(state(requests, jev))); return { dir, policyPath } }
const answerFetch = (calls: { count: number }): FetchLike => async () => { calls.count++; return { ok: true, status: 200, text: async () => JSON.stringify({ answers: { next: { type: "choice", choice: "RESEARCH", confidence: 0.5, probabilities: { RESEARCH: 0.5, WAIT: 0.5 } } } }) } }

test("P4 credential denies before transport and state write", async () => { const fx = await fixture(), calls = { count: 0 }; try { const before = await readFile(join(fx.dir, ".loop", "state.json"), "utf8"); const outcome = await runDecision(packet(), { projectDir: fx.dir, policyPath: fx.policyPath, fetch: answerFetch(calls) }); assert.equal(outcome.reason?.code, "denied.missing-api-key"); assert.ok((outcome.reason?.message ?? "").includes(API_KEY_VARIABLE)); assert.equal(calls.count, 0); assert.equal(await readFile(join(fx.dir, ".loop", "state.json"), "utf8"), before) } finally { await rm(fx.dir, { recursive: true, force: true }) } })
test("P4 one synthetic call preserves named historical counters", async () => { const fx = await fixture(), calls = { count: 0 }, synthetic = "synthetic-test-credential-not-a-real-secret"; try { const outcome = await runDecision(packet(), { projectDir: fx.dir, policyPath: fx.policyPath, apiKey: synthetic, fetch: answerFetch(calls) }); assert.equal(outcome.accepted, true); assert.equal(calls.count, 1); assert.deepEqual(JSON.parse(await readFile(join(fx.dir, ".loop", "state.json"), "utf8")).requestCounters, { lifetimeModelProviderRequests: 24, jevRequests: 3 }); assert.equal((await readFile(join(fx.dir, ".loop", "runs", "r1", "decisions", "d1.json"), "utf8")).includes(synthetic), false) } finally { await rm(fx.dir, { recursive: true, force: true }) } })
test("P4 budget and interruption lock fail closed", async () => { const capped = await fixture(80, 2), locked = await fixture(), calls = { count: 0 }; try { assert.equal((await runDecision(packet(), { projectDir: capped.dir, policyPath: capped.policyPath, apiKey: "synthetic", fetch: answerFetch(calls) })).reason?.code, "denied.call-budget"); await writeFile(join(locked.dir, ".loop", "jev.lock"), "interrupted-holder"); assert.equal((await runDecision(packet(), { projectDir: locked.dir, policyPath: locked.policyPath, apiKey: "synthetic", fetch: answerFetch(calls), lockRetries: 0 })).reason?.code, "denied.lock"); assert.equal(calls.count, 0) } finally { await rm(capped.dir, { recursive: true, force: true }); await rm(locked.dir, { recursive: true, force: true }) } })

test("P4 billing admission uses only exact enabled policy classes", async () => {
  const policyWith = (billingClasses: Record<string, boolean>) => ({ ...policy, routingPolicy: { billingClasses } })
  const disabled = await fixture(23, 2, policyWith({ includedSubscription: false, temporaryCredit: false }))
  const missing = await fixture(23, 2, { ...policy, routingPolicy: {} })
  const misleading = await fixture(23, 2, policyWith({ includedElsewhere: true, temporaryCredit: false }))
  const calls = { count: 0 }
  try {
    for (const fx of [disabled, misleading]) assert.equal((await runDecision(packet(), { projectDir: fx.dir, policyPath: fx.policyPath, apiKey: "synthetic", fetch: answerFetch(calls) })).reason?.code, "packet.paid-capacity")
    assert.equal((await runDecision(packet("misleading", "unincluded-overage"), { projectDir: misleading.dir, policyPath: join(misleading.dir, "policy.json"), apiKey: "synthetic", fetch: answerFetch(calls) })).reason?.code, "packet.paid-capacity")
    assert.equal((await runDecision(packet(), { projectDir: missing.dir, policyPath: missing.policyPath, apiKey: "synthetic", fetch: answerFetch(calls) })).reason?.code, "denied.policy-unavailable")
    assert.equal(calls.count, 0)
  } finally { for (const fx of [disabled, missing, misleading]) await rm(fx.dir, { recursive: true, force: true }) }
})

test("P4 temporary-credit fallback requires the exact enabled normalized class", async () => {
  const temporaryQuestion = { id: "fallback", type: "choice" as const, instructions: "choose fallback", options: [{ id: "ALTERNATE_SUBSCRIPTION", description: "included route" }, { id: "TEMPORARY", description: "approved temporary route", billingClass: "temporary-credit" }] }
  const temporaryPacket = { schemaVersion: "loop-jev-admission/1", projectId: "runtime-test", runId: "r1", decisionId: "temporary", contract: "PROVIDER_FALLBACK", composition: { id: "direct-choice", version: "1" }, admission: { gate: "test", questionsDigest: digestQuestions("PROVIDER_FALLBACK", [temporaryQuestion]), authority: { billingClass: "temporary-credit", paidCapacity: false, permissionEscalation: false, verificationWaived: false, completionWaived: false, completionPreconditionsPassed: false } }, state: { nonSecret: true }, questions: [temporaryQuestion] }
  const policyWith = (billingClasses: Record<string, boolean>) => ({ ...policy, routingPolicy: { billingClasses } })
  const enabled = await fixture(23, 2, policyWith({ includedSubscription: true, temporaryCredit: true })), disabled = await fixture(23, 2, policyWith({ includedSubscription: true, temporaryCredit: false })), calls = { count: 0 }
  const temporaryFetch: FetchLike = async () => { calls.count++; return { ok: true, status: 200, text: async () => JSON.stringify({ answers: { fallback: { type: "choice", choice: "TEMPORARY", confidence: 0.5, probabilities: { ALTERNATE_SUBSCRIPTION: 0.5, TEMPORARY: 0.5 } } } }) } }
  try {
    assert.equal((await runDecision(temporaryPacket, { projectDir: enabled.dir, policyPath: enabled.policyPath, apiKey: "synthetic", fetch: temporaryFetch })).accepted, true)
    assert.equal((await runDecision(temporaryPacket, { projectDir: disabled.dir, policyPath: disabled.policyPath, apiKey: "synthetic", fetch: temporaryFetch })).reason?.code, "packet.paid-capacity")
    assert.equal(calls.count, 1)
    assert.equal(JSON.parse(await readFile(join(enabled.dir, ".loop", "state.json"), "utf8")).lifetime.paidSpendUsed, 0)
  } finally { await rm(enabled.dir, { recursive: true, force: true }); await rm(disabled.dir, { recursive: true, force: true }) }
})
