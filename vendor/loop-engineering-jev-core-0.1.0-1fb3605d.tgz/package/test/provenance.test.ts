import assert from "node:assert/strict"
import { spawnSync } from "node:child_process"
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises"
import { test } from "node:test"

const sourceRoot = "/Users/emmantalob/dev/personal-ui-system/tools/loop/jev"
const pinnedCommit = "dedf949702e9b869670cbb3bc344d4e1b220f4dd"
const run = (env: Record<string, string | undefined> = {}) => spawnSync("sh", ["scripts/check-provenance.sh"], { cwd: process.cwd(), encoding: "utf8", env: { ...process.env, ...env } })

test("pinned Git blobs survive later checkout HEAD while missing objects, paths, and drift fail closed", async () => {
  // The supplied checkout is deliberately at a later HEAD; immutable pinned blobs still pass.
  assert.equal(run().status, 0)
  assert.equal(run({ PROVENANCE_TEST_MODE: "1", PROVENANCE_TEST_EXPECTED_COMMIT: "0000000000000000000000000000000000000000" }).status, 1)
  assert.equal(run({ PROVENANCE_TEST_MODE: "1", PROVENANCE_TEST_PATH_PREFIX: "missing/path" }).status, 1)
  assert.equal(run({ PROVENANCE_TEST_MODE: "1", PROVENANCE_TEST_TYPES_HASH: "0000000000000000000000000000000000000000000000000000000000000000" }).status, 1)
  const root = await mkdtemp("./.provenance-fixture-")
  try {
    await mkdir(`${root}/src`)
    for (const name of ["types.ts", "accept.ts", "packet.ts", "compose.ts"]) await writeFile(`${root}/src/${name}`, await readFile(`src/${name}`, "utf8"), { encoding: "utf8" })
    await writeFile(`${root}/src/types.ts`, "drift\n", { encoding: "utf8" })
    assert.equal(run({ PROVENANCE_TEST_MODE: "1", PROVENANCE_TEST_SOURCE_ROOT: sourceRoot, PROVENANCE_TEST_EXPECTED_COMMIT: pinnedCommit, PROVENANCE_TEST_EXTRACTED_ROOT: root }).status, 1)
  } finally { await rm(root, { recursive: true, force: true }) }
})
