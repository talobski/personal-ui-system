import assert from "node:assert/strict"
import { test } from "node:test"
import { chmod, mkdtemp, readFile, rm, symlink, writeFile } from "node:fs/promises"
import { join } from "node:path"
import { GLOBAL_POLICY_V2, PROJECT_STATE_V2, migrateGlobalPolicyFile, migrateGlobalPolicyV1, migrateProjectStateFile, migrateProjectStateV1, rollbackGlobalPolicyFile, sha256, stableJson, validateGlobalPolicyV2, validateProjectStateV2 } from "../src/state-policy.ts"
import { phaseEntryBootstrapV1 } from "./fixtures/phase-entry-bootstrap-v1.fixture.ts"
import { phase2EvolvedBootstrapV1 } from "./fixtures/phase-2-evolved-bootstrap-v1.fixture.ts"

const legacyPolicy = { schemaVersion: 1, updatedAt: "2026-09-21T00:00:00Z", ownerCeilings: { paidBudget: 0, maxCallsPerProject: 80, maxAgentRunsPerProject: 14, defaultMaxAttemptsPerTask: 4, maxWorkerConcurrency: 1, maxSpawnDepth: 1 }, authority: { humanExecutesProduction: true }, routingPolicy: { noAutoRecharge: true, preferredClasses: ["included"] }, providers: { jev: { lastFixture: { project: "loop-engineering-runtime" } }, codex: { observed: "UNKNOWN" } } }
const legacyProject = { schemaVersion: "bootstrap-v1", projectId: "loop-engineering-runtime", phase: "RUNNING", activeUnit: { taskId: "p2-producer" }, acceptedLine: "main", lifetime: { agentRunsUsed: 9, agentRunCeiling: 16, paidSpendCeiling: 0, paidSpendUsed: 0 }, phasePlan: { phaseId: "phase-2", status: "RUNNING", allocation: { agentRuns: 4, normalAgentRuns: 2, preapprovedRemediationAgentRuns: 2, leadToWorkerTurns: 4, phaseAttempts: 4, concurrency: 1, paidSpend: 0 }, counters: { agentRuns: 1, leadToWorkerTurns: 1, phaseAttempts: 1, activeWorkers: 1 }, reservedRoles: ["producer", "verifier"], delegationStrategy: "PRODUCER_VERIFIER", acceptanceCriteria: ["P2-01"] }, tasks: [{ taskId: "p1", status: "accepted", role: "producer", result: "accepted" }, { taskId: "p2-producer", status: "running", role: "producer", runId: "r9", workspaceId: "w9" }], inFlight: [{ runId: "r9", taskId: "p2-producer" }], providerStates: { jev: { credentialVariable: "TYPESAFE_LOOP_ENGINEERING_API_KEY" } }, bootstrap: { sourceCommit: "fd71dfc" }, runtime: { acceptedCommit: "fd71dfc", phaseCompletionEvidence: ".loop/runs/phase-1-promotion/result.json", preflightEvidence: ".loop/runs/preflight.json", paseoProjectId: "p", paseoProjectKind: "local" }, jevConfiguration: { credentialVariable: "TYPESAFE_LOOP_ENGINEERING_API_KEY" }, pause: null, phase2PolicyMigration: { status: "pending" }, lastUpdated: "2026-09-21T00:00:00Z" }

test("v1 policy maps the legacy 80 request unit exactly and is byte-stable", () => {
  const migrated = migrateGlobalPolicyV1(legacyPolicy); assert.ok(migrated.ok)
  assert.equal(migrated.value.schemaVersion, GLOBAL_POLICY_V2)
  assert.equal(migrated.value.declarationCaps.maxLifetimeModelProviderRequestsPerProject, 80)
  assert.deepEqual(migrated.value.ownerExecutionDefaults, { defaultMaxAttemptsPerTask: 4, maxWorkerConcurrency: 1, maxSpawnDepth: 1 })
  assert.equal((migrated.value.providerMetadata.jev as { lastFixture: { project: string } }).lastFixture.project, "loop-engineering-runtime")
  assert.equal("maxLeadToWorkerTurnsPerProject" in migrated.value.declarationCaps, false)
  assert.equal("phaseDefaults" in migrated.value, false)
  const again = migrateGlobalPolicyV1(migrated.value); assert.ok(again.ok)
  assert.equal(stableJson(again.value), stableJson(migrated.value))
})

test("global contract fails closed for unknown, project-scope, paid, and credential fields", () => {
  const good = migrateGlobalPolicyV1(legacyPolicy); assert.ok(good.ok)
  for (const bad of [{ ...good.value, phase: "RUNNING" }, { ...good.value, paidBudget: 1 }, { ...good.value, providerMetadata: { apiKey: "synthetic" } }, { ...good.value, providerMetadata: { nested: { taskId: "x" } } }, { ...good.value, schemaVersion: "loop-global-policy/3" }]) assert.equal(validateGlobalPolicyV2(bad).ok, false)
})

test("pinned Phase-entry bootstrap migration preserves accepted Phase 1 history byte-stably", () => {
  const migrated = migrateProjectStateV1(phaseEntryBootstrapV1); assert.ok(migrated.ok)
  assert.equal(migrated.value.schemaVersion, PROJECT_STATE_V2)
  assert.deepEqual(migrated.value.lifetime, { agentRunCeiling: 16, agentRunsUsed: 8, paidSpendCeiling: 0, paidSpendUsed: 0 })
  assert.equal(migrated.value.phaseHistory[0]?.immutable, true)
  assert.deepEqual(migrated.value.inFlight, [])
  assert.deepEqual(migrated.value.tasks, phaseEntryBootstrapV1.tasks)
  assert.deepEqual(migrated.value.results, phaseEntryBootstrapV1.tasks.map(({ taskId, result }) => ({ taskId, result })))
  assert.deepEqual(migrated.value.accepted, { line: "main", commit: "fd71dfc80f534d28f2019ddd069558bce66ed344", evidenceRefs: [".loop/runs/phase-1-promotion/result.json", ".loop/runs/phase-1-preflight/result.json"] })
  assert.deepEqual(migrated.value.phasePlan, phaseEntryBootstrapV1.phasePlan)
  const again = migrateProjectStateV1(migrated.value); assert.ok(again.ok)
  assert.equal(stableJson(again.value), stableJson(migrated.value))
  const unsafe = structuredClone(migrated.value); unsafe.providerObservations.jev = { credentialVariable: "not-safe" }
  assert.equal(validateProjectStateV2(unsafe).ok, false)
  const secret = structuredClone(migrated.value); secret.providerObservations.jev = { apiKey: "synthetic" }
  assert.equal(validateProjectStateV2(secret).ok, false)
  assert.equal(validateProjectStateV2({ ...migrated.value, declarationCaps: {} }).ok, false)
  assert.equal(validateProjectStateV2({ ...migrated.value, schemaVersion: "loop-project-state/3" }).ok, false)
})

test("evolved P2-08 snapshot preserves bounded counters and in-flight transitions", () => {
  const activeResult = migrateProjectStateV1(phase2EvolvedBootstrapV1); assert.ok(activeResult.ok)
  assert.deepEqual(activeResult.value.lifetime, { agentRunCeiling: 16, agentRunsUsed: 10, paidSpendCeiling: 0, paidSpendUsed: 0 })
  assert.deepEqual(activeResult.value.phasePlan.allocation, { agentRuns: 4, normalAgentRuns: 2, preapprovedRemediationAgentRuns: 2, leadToWorkerTurns: 4, phaseAttempts: 4, concurrency: 1, paidSpend: 0 })
  assert.deepEqual(activeResult.value.phasePlan.counters, { agentRuns: 2, leadToWorkerTurns: 4, phaseAttempts: 1, activeWorkers: 1 })
  assert.deepEqual(activeResult.value.inFlight, phase2EvolvedBootstrapV1.inFlight)
  const cleared = { ...phase2EvolvedBootstrapV1, activeUnit: null, phasePlan: { ...phase2EvolvedBootstrapV1.phasePlan, counters: { ...phase2EvolvedBootstrapV1.phasePlan.counters, activeWorkers: 0 } }, inFlight: [] }
  const clearedResult = migrateProjectStateV1(cleared); assert.ok(clearedResult.ok)
  assert.deepEqual(clearedResult.value.inFlight, [])
})

test("explicit-path migration is dry-run safe, atomic/recoverable, and rejects unsafe source", async () => {
  const dir = await mkdtemp("./.policy-test-")
  const source = join(dir, "policy.json"), original = JSON.stringify(legacyPolicy, null, 2) + "\n", originalHash = sha256(original)
  try {
    await writeFile(source, original, { mode: 0o600 }); await chmod(source, 0o600)
    const request = { path: source, expectedSha256: originalHash, expectedSchemaVersion: 1 as const, expectedMode: 0o600 }
    await assert.rejects(migrateGlobalPolicyFile({ ...request, mode: "dry-run", expectedSha256: "0".repeat(64) }), /hash drift/)
    const dry = await migrateGlobalPolicyFile({ ...request, mode: "dry-run" }); assert.equal(dry.backupPath, null); assert.equal(await readFile(source, "utf8"), original)
    await assert.rejects(migrateGlobalPolicyFile({ ...request, mode: "apply", simulateInterruption: true }), /interruption/); assert.equal(await readFile(source, "utf8"), original)
    const receipt = await migrateGlobalPolicyFile({ ...request, mode: "apply" }); assert.equal(receipt.backupSha256, originalHash); assert.equal(sha256(await readFile(receipt.backupPath!, "utf8")), originalHash)
    await rollbackGlobalPolicyFile(receipt); assert.equal(await readFile(source, "utf8"), original)
    await chmod(source, 0o644); await assert.rejects(rollbackGlobalPolicyFile(receipt), /rollback precondition drift|validation failed/); await chmod(source, 0o600)
    const link = join(dir, "policy-link.json"); await symlink(source, link)
    await assert.rejects(migrateGlobalPolicyFile({ ...request, path: link, mode: "dry-run" }), /non-symlink regular/)
  } finally { await rm(dir, { recursive: true, force: true }) }
})

test("project-state file migration and last-moment drift are explicit and fail closed", async () => {
  const dir = await mkdtemp("./.state-test-"), source = join(dir, "state.json"), original = JSON.stringify(legacyProject, null, 2) + "\n"
  try {
    await writeFile(source, original, { mode: 0o600 }); await chmod(source, 0o600)
    const request = { path: source, expectedSha256: sha256(original), expectedSchemaVersion: "bootstrap-v1" as const, expectedMode: 0o600 }
    const dry = await migrateProjectStateFile({ ...request, mode: "dry-run" }); assert.equal(dry.backupPath, null)
    await assert.rejects(migrateProjectStateFile({ ...request, mode: "apply", beforeFinalRename: async () => { await writeFile(source, original + " ") } }), /drift before final rename/)
    assert.equal(await readFile(source, "utf8"), original + " ")
  } finally { await rm(dir, { recursive: true, force: true }) }
})
