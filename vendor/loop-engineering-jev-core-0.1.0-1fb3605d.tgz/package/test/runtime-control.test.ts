import assert from "node:assert/strict"
import { createHash } from "node:crypto"
import { readFile } from "node:fs/promises"
import { test } from "node:test"
import { CLAUDE_STRONG_WORKER_PROFILE, CODEX_STRONG_WORKER_PROFILE, createSyntheticNegativeReceipts, validateNegativeAdmissionFixture, validateWorkerProfile } from "../src/profile-routing.ts"
import { acceptEvidence, admitBoundedRecovery, admitExecutionPolicy, admitSameVerifierRecovery, aggregateVerificationEvidence, bindModelClass, checkVerifierReadiness, classifyOperationalFailure, classifyVerificationOutcome, composeModelClassPacket, consumeMaxApproval, createCurrentControlReceipt, createOptedInActivationPlan, createStrongActivationPlan, cumulativeExecutionMs, decideContinuation, decideGateDerivedContinuation, filterRoutesForClass, preflightVerifier, resolvePermissionOnce } from "../src/runtime-control.ts"
import { p6EvidenceAggregationFixtures } from "./fixtures/phase-6-evidence-aggregation.fixture.ts"

const freshPass = { source: "FRESH_VERIFIER" as const, candidateCommit: "candidate", scopeHash: "scope", outcome: "PASS" as const }
const preflight = { verifierId: "standard-verifier", candidateCommit: "candidate", candidateHash: "candidate-hash", controlHash: "controls-hash", expectedCandidateCommit: "candidate", expectedCandidateHash: "candidate-hash", expectedControlHash: "controls-hash", currentPathCapabilities: ["filesystem", "shell", "typescript"], requiredCapabilities: ["filesystem", "typescript"], protectedRunReserved: true as const }

test("P5-01 continuation executes the sole bounded option, chooses only among multiple options, and fails closed", () => {
  assert.deepEqual(decideContinuation([{ id: "same-verifier", kind: "retry", safe: true, withinHeadroom: true }], false, 1), { action: "EXECUTE", option: { id: "same-verifier", kind: "retry", safe: true, withinHeadroom: true }, logged: true })
  assert.equal(decideContinuation([{ id: "retry", kind: "retry", safe: true, withinHeadroom: true }, { id: "owner", kind: "interrupt", safe: true, withinHeadroom: true }], false, 1).action, "DECIDE")
  for (const [result, reason] of [[decideContinuation([{ id: "retry", kind: "retry", safe: true, withinHeadroom: true }], true, 1), "HARD_BOUNDARY"], [decideContinuation([{ id: "retry", kind: "retry", safe: true, withinHeadroom: true }], false, 0), "HEADROOM_EXHAUSTED"], [decideContinuation([{ id: "unsafe", kind: "retry", safe: false, withinHeadroom: true }], false, 1), "NO_SAFE_OPTION"]] as const) { assert.equal(result.action, "FAIL_CLOSED"); if (result.action === "FAIL_CLOSED") assert.equal(result.reason, reason) }
})

test("P5-02 preflight binds current capability plus exact candidate and controls before protected dispatch", () => {
  const receipt = preflightVerifier(preflight); assert.ok(receipt.ok); if (receipt.ok) assert.equal(receipt.value.protectedRunConsumed, false)
  for (const drift of [{ expectedCandidateCommit: "other" }, { expectedCandidateHash: "other" }, { expectedControlHash: "other" }, { currentPathCapabilities: ["filesystem"] }]) assert.equal(preflightVerifier({ ...preflight, ...drift }).ok, false)
})

test("P5-03 outcomes are closed and P5-04 provenance cannot be impersonated", () => {
  assert.deepEqual([classifyVerificationOutcome({}), classifyVerificationOutcome({ productFailure: true }), classifyVerificationOutcome({ contractFailure: true }), classifyVerificationOutcome({ environmentBlocked: true }), classifyVerificationOutcome({ capabilityBlocked: true })], ["PASS", "FAIL_PRODUCT", "FAIL_CONTRACT", "BLOCKED_ENVIRONMENT", "BLOCKED_CAPABILITY"])
  assert.ok(acceptEvidence(freshPass, true).ok)
  assert.equal(acceptEvidence({ ...freshPass, source: "LEAD" }, true).ok, false)
  assert.equal(acceptEvidence({ ...freshPass, source: "BLOCKED_ENVIRONMENT", outcome: "PASS" }, false).ok, false)
  assert.ok(acceptEvidence({ ...freshPass, source: "BLOCKED_ENVIRONMENT", outcome: "BLOCKED_CAPABILITY" }, false).ok)
})

test("P5-05 same-verifier recovery is identity, scope, controls, permissions, and capability bound", () => {
  const initial = { verifierId: "v", candidateCommit: "c", scopeHash: "s", controlHash: "control", permissionHash: "permissions" }
  const request = { ...initial, initial, newAgentRun: false as const, network: false as const, credentialAccess: false as const, paidSpend: 0 as const, concurrency: 1 as const, productMutation: false as const, testMutation: false as const }
  assert.ok(admitSameVerifierRecovery(request).ok)
  for (const drift of [{ verifierId: "other" }, { candidateCommit: "other" }, { scopeHash: "other" }, { controlHash: "other" }, { permissionHash: "other" }, { newAgentRun: true }, { network: true }, { credentialAccess: true }, { paidSpend: 1 }, { concurrency: 2 }, { productMutation: true }, { testMutation: true }]) assert.equal(admitSameVerifierRecovery({ ...request, ...drift } as never).ok, false)
})

test("P5-06 model class binds profile hashes, precedes class-filtered routing, and rejects fallback", () => {
  const standard = bindModelClass(CODEX_STRONG_WORKER_PROFILE, "STANDARD"), strong = bindModelClass(CODEX_STRONG_WORKER_PROFILE, "STRONG")
  assert.ok(standard.bindingHash !== strong.bindingHash)
  const singleton = composeModelClassPacket(["STANDARD"], "r", "d"); assert.ok(singleton.ok); if (singleton.ok) assert.equal(singleton.value, null, "singleton class skips Jev")
  const packet = composeModelClassPacket(["STANDARD", "STRONG"], "r", "d"); assert.ok(packet.ok && packet.value && packet.value.contract === "MODEL_CLASS")
  assert.equal(filterRoutesForClass([strong], "STANDARD").ok, false)
  const filtered = filterRoutesForClass([strong], "STRONG"); assert.ok(filtered.ok); if (filtered.ok) assert.equal(filtered.value.length, 1)
  assert.equal(filterRoutesForClass([strong], "MAX").ok, false)
})

test("P5-07 Strong declarations are exact, admission-tested, and Standard artifact bytes remain unchanged", async () => {
  for (const [profile, artifact] of [[CODEX_STRONG_WORKER_PROFILE, "profiles/codex-strong-worker.profile.json"], [CLAUDE_STRONG_WORKER_PROFILE, "profiles/claude-strong-worker.profile.json"]] as const) {
    assert.deepEqual(JSON.parse(await readFile(artifact, "utf8")), profile); assert.ok(validateWorkerProfile(profile).ok); assert.ok(validateNegativeAdmissionFixture(createSyntheticNegativeReceipts(profile), profile).ok)
  }
  assert.equal(CODEX_STRONG_WORKER_PROFILE.model, "gpt-5.6-sol"); assert.equal(CLAUDE_STRONG_WORKER_PROFILE.model, "claude-opus-5")
  const digest = async (path: string) => createHash("sha256").update(await readFile(path, "utf8")).digest("hex")
  assert.equal(await digest("profiles/codex-worker.profile.json"), "7af2024bf114c62dbfba30408f9acdb716cb19695b0551ff548587dea1bcd811")
  assert.equal(await digest("profiles/claude-worker.profile.json"), "47cff0466630a73dea24fda1b9001437d867a03b7d4ee812a9feaec7b7bff155")
})

test("P5-08 MAX is recommendation-only until exact one-use approval and cannot replay", () => {
  const recommendation = { taskId: "task", profileId: "max-profile", model: "max-model", effort: "medium" as const, recommended: true as const }
  const approval = { ...recommendation, approvalId: "approval", nonce: "nonce", ownerApproved: true as const }
  assert.equal(consumeMaxApproval(recommendation, undefined, new Set()).ok, false)
  assert.ok(consumeMaxApproval(recommendation, approval, new Set()).ok)
  assert.equal(consumeMaxApproval(recommendation, approval, new Set(["approval"])).ok, false)
  assert.equal(consumeMaxApproval({ ...recommendation, taskId: "other" }, approval, new Set()).ok, false)
})

test("P5-09/P5-11 Strong activation is Lead-only, post-PASS, hash-bound, and has rollback evidence", () => {
  const strong = bindModelClass(CODEX_STRONG_WORKER_PROFILE, "STRONG")
  const plan = createStrongActivationPlan("candidate", freshPass, [strong], "registry-before", "controls")
  assert.ok(plan.ok); if (plan.ok) { assert.equal(plan.value.activation, false); assert.equal(plan.value.leadOnly, true); assert.equal(plan.value.rollback.beforeRegistryHash, "registry-before") }
  assert.equal(createStrongActivationPlan("candidate", { ...freshPass, source: "LEAD" }, [strong], "registry", "controls").ok, false)
  assert.equal(createStrongActivationPlan("other", freshPass, [strong], "registry", "controls").ok, false)
})

const p6Policy = { schemaVersion: "loop-execution-policy/1" as const, phaseId: "phase-6", migration: "EXPLICIT_MIGRATION" as const, lifetime: { maxAgentRuns: 28, usedAgentRuns: 24 }, phase: { maxAgentCreations: 4, usedAgentCreations: 1, cumulativeWallClockMs: 10, maxWallClockMs: 28_800_000, protectedVerifierReserved: true as const }, telemetry: { leadTurns: 99, phaseAttempts: 99, recoverySteps: 99 }, hardControls: { concurrency: 1 as const, paidSpend: 0 as const, network: false as const, credentialAccess: false as const, externalAction: false as const } }

test("P6-01 new/migrated policies hard-limit lifetime/run/time while counters are telemetry", () => {
  assert.ok(admitExecutionPolicy(p6Policy, 1, 5).ok)
  assert.equal(admitExecutionPolicy({ ...p6Policy, lifetime: { ...p6Policy.lifetime, usedAgentRuns: 28 } }, 1, 0).ok, false)
  assert.equal(admitExecutionPolicy({ ...p6Policy, hardControls: { ...p6Policy.hardControls, concurrency: 2 } as never }, 0, 0).ok, false)
  assert.equal(admitExecutionPolicy(p6Policy, 0, 28_800_000).ok, false)
})

test("P6-02 supervisor accumulates phase wall clock once and only excludes fully stopped waits", () => {
  assert.deepEqual(cumulativeExecutionMs({ schemaVersion: "loop-execution-time-supervisor/1", phaseId: "p", startedAtMs: 0, observedAtMs: 100, stoppedWaits: [{ startedAtMs: 10, endedAtMs: 30, fullyStopped: true }, { startedAtMs: 20, endedAtMs: 50, fullyStopped: true }] }), { ok: true, value: 60 })
  assert.equal(cumulativeExecutionMs({ schemaVersion: "loop-execution-time-supervisor/1", phaseId: "p", startedAtMs: 0, observedAtMs: 100, stoppedWaits: [{ startedAtMs: 10, endedAtMs: 30, fullyStopped: false }] as never }).ok, false)
})

test("P6-03 deterministic gate singleton READY_FOR_G7 executes without Jev and missing evidence fails closed", () => {
  assert.equal(decideGateDerivedContinuation({ gate: "READY_FOR_G7", admissible: true, evidenceHash: "e" }, true).action, "EXECUTE")
  assert.equal(decideGateDerivedContinuation(null, true).action, "FAIL_CLOSED")
  assert.equal(decideGateDerivedContinuation({ gate: "READY_FOR_G7", admissible: true, evidenceHash: "e" }, false).action, "FAIL_CLOSED")
})

test("P6-04 criterion-scoped verifier readiness occurs before protected run consumption", () => {
  const ready = { profileId: "claude-standard", environmentId: "offline", candidateCommit: "c", artifactHash: "a", criteria: [{ criterionId: "P6-12", requiredCapabilities: ["shell", "typescript"] }], availableCapabilities: ["shell", "typescript"], protectedRunReserved: true as const }
  const receipt = checkVerifierReadiness(ready); assert.ok(receipt.ok); if (receipt.ok) assert.equal(receipt.value.protectedRunConsumed, false)
  assert.equal(checkVerifierReadiness({ ...ready, availableCapabilities: ["shell"] }).ok, false)
})

test("P6-05 compact failures distinguish candidate failure from environment and capability blocks", () => {
  assert.deepEqual([classifyOperationalFailure({ artifactFailure: true }), classifyOperationalFailure({ environmentBlocked: true }), classifyOperationalFailure({ capabilityBlocked: true }), classifyOperationalFailure({})], ["ARTIFACT_FAILURE", "ENVIRONMENT_BLOCK", "CAPABILITY_BLOCK", null])
})

test("P6-06 evidence aggregation preserves fresh verifier failures and blocks while failing closed on invalid provenance", () => {
  const fixtures = p6EvidenceAggregationFixtures
  assert.equal(aggregateVerificationEvidence([fixtures.leadPass], "candidate", true).ok, false)
  for (const [evidence, outcome] of [[fixtures.freshPass, "PASS"], [fixtures.freshProductFailure, "ARTIFACT_FAILURE"], [fixtures.freshContractFailure, "ARTIFACT_FAILURE"], [fixtures.freshEnvironmentBlock, "ENVIRONMENT_BLOCK"], [fixtures.freshCapabilityBlock, "CAPABILITY_BLOCK"]] as const) {
    const result = aggregateVerificationEvidence([evidence], "candidate", true)
    assert.ok(result.ok); if (result.ok) { assert.equal(result.value.outcome, outcome); assert.deepEqual(result.value.evidence, [evidence]) }
  }
  for (const invalid of [[{ ...fixtures.freshPass, fresh: false }], [{ ...fixtures.freshPass, candidateCommit: "drift" }], [{ ...fixtures.freshPass, source: "BLOCKED_ENVIRONMENT" as const, outcome: "PASS" as const, fresh: false }]]) assert.equal(aggregateVerificationEvidence(invalid, "candidate", true).ok, false)
})

test("P6-07 permission resolution requests exactly once and converges without replay", () => {
  assert.deepEqual(resolvePermissionOnce({ requestId: "r", requested: true, reconciliation: "GRANTED", priorRequests: 0 }), { ok: true, value: "GRANTED" })
  assert.deepEqual(resolvePermissionOnce({ requestId: "r", requested: true, reconciliation: "DENIED_CAPABILITY", priorRequests: 0 }), { ok: true, value: "BLOCKED_CAPABILITY" })
  assert.deepEqual(resolvePermissionOnce({ requestId: "r", requested: true, reconciliation: "OWNER_REQUIRED", priorRequests: 0 }), { ok: true, value: "OWNER_REQUIRED" })
  assert.equal(resolvePermissionOnce({ requestId: "r", requested: true, reconciliation: "GRANTED", priorRequests: 1 }).ok, false)
})

test("P6-08 current-control receipt binds candidate artifact and every active hard control", async () => {
  const policyHash = createHash("sha256").update(JSON.stringify(p6Policy)).digest("hex")
  // Stable JSON hashing is deliberately checked by the receipt, not this JSON shortcut.
  const invalid = createCurrentControlReceipt({ candidateCommit: "c", artifactHash: "a", executionPolicyHash: policyHash, concurrency: 1, paidSpend: 0, verifierId: "v", verifierScopeHash: "s", capabilitiesHash: "wrong", controlMetadataHash: "m" }, p6Policy, ["shell"])
  assert.equal(invalid.ok, false)
  const { sha256, stableJson } = await import("../src/state-policy.ts")
  assert.ok(createCurrentControlReceipt({ candidateCommit: "c", artifactHash: "a", executionPolicyHash: sha256(stableJson(p6Policy)), concurrency: 1, paidSpend: 0, verifierId: "v", verifierScopeHash: "s", capabilitiesHash: sha256(stableJson(["shell"])), controlMetadataHash: "m" }, p6Policy, ["shell"]).ok)
})

test("P6-09 bounded same-verifier recovery uses phase envelope and stops after two stagnant steps", () => {
  const initial = { verifierId: "v", candidateCommit: "c", scopeHash: "s", controlHash: "h", permissionHash: "p" }
  const request = { ...initial, initial, newAgentRun: false as const, network: false as const, credentialAccess: false as const, paidSpend: 0 as const, concurrency: 1 as const, productMutation: false as const, testMutation: false as const, policy: p6Policy, recoveryStep: 1, newEvidence: false, measurableProgress: false }
  assert.ok(admitBoundedRecovery(request).ok)
  assert.equal(admitBoundedRecovery({ ...request, recoveryStep: 2 }).ok, false)
  assert.ok(admitBoundedRecovery({ ...request, recoveryStep: 2, newEvidence: true }).ok)
  assert.equal(admitBoundedRecovery({ ...request, recoveryStep: 3, newEvidence: true }).ok, false)
})

test("P6-10 retains Phase 5 class controls and P6-11 emits inactive opted-in Lead-only activation", () => {
  assert.equal(consumeMaxApproval({ taskId: "t", profileId: "p", model: "m", effort: "medium", recommended: true }, undefined, new Set()).ok, false)
  const plan = createOptedInActivationPlan("phase-6", p6Policy, { ...freshPass, candidateCommit: "candidate" }, "before", "backup")
  assert.ok(plan.ok); if (plan.ok) assert.equal(plan.value.activation, false)
  assert.equal(createOptedInActivationPlan("phase-6", { ...p6Policy, migration: "NEW" }, { ...freshPass, candidateCommit: "candidate" }, "before", "backup").ok, false)
})
