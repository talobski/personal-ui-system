import type {
  AcceptedAnswer, AdmissionPacket, Authority, ChoiceOption, ChoiceQuestion, Json, NoulQuestion, Outcome, Question, Reason, ReasonCode, ScoreQuestion,
} from "../src/types.ts"
import { DECISION_SCHEMA_VERSION, EVENT_SCHEMA_VERSION, PACKET_SCHEMA_VERSION } from "../src/types.ts"

type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends (<T>() => T extends B ? 1 : 2) ? true : false
type Assert<T extends true> = T
type _PacketVersion = Assert<Equal<typeof PACKET_SCHEMA_VERSION, "loop-jev-admission/1">>
type _DecisionVersion = Assert<Equal<typeof DECISION_SCHEMA_VERSION, "loop-jev-decision/1">>
type _EventVersion = Assert<Equal<typeof EVENT_SCHEMA_VERSION, "loop-jev-event/1">>
type _ReasonCode = Assert<Equal<Extract<ReasonCode, "failed.noul-unresolved">, "failed.noul-unresolved">>
type _AuthorityKeys = Assert<Equal<keyof Authority, "billingClass" | "paidCapacity" | "permissionEscalation" | "verificationWaived" | "completionWaived" | "completionPreconditionsPassed">>

export const choice: ChoiceQuestion = { id: "next", type: "choice", instructions: "Select.", options: [{ id: "WAIT", description: "Wait." }, { id: "VERIFY", description: "Verify." }] }
export const score: ScoreQuestion = { id: "score", type: "score", instructions: "Rate.", scale: ["low", "high"] }
export const noul: NoulQuestion = { id: "human", type: "noul", instructions: "Need human?", criteria: { true: "yes", false: "no" } }
export const option: ChoiceOption = { id: "WAIT", description: "Wait." }
export const question: Question = choice
export const answer: AcceptedAnswer = { type: "choice", choice: "WAIT", confidence: 0.5, probabilities: { WAIT: 0.5, VERIFY: 0.5 } }
export const reason: Reason = { code: "failed.confidence", message: "fixed threshold" }
export const json: Json = { ok: true, values: [null, 1, "x"] }

export const packet: AdmissionPacket = {
  schemaVersion: PACKET_SCHEMA_VERSION, projectId: "project", runId: "run", decisionId: "decision", contract: "NEXT_ACTION",
  composition: { id: "direct-choice", version: "1" },
  admission: { gate: "gate", questionsDigest: "digest", authority: { billingClass: "included", paidCapacity: false, permissionEscalation: false, verificationWaived: false, completionWaived: false, completionPreconditionsPassed: false } },
  state: { contract: "NEXT_ACTION", questions: "admitted", answers: "none", fallback: "WAIT", reason: "synthetic" }, questions: [choice], fallback: { id: "fallback", output: "WAIT" },
}

export const outcome: Outcome = { accepted: false, status: "failed", runId: "run", decisionId: "decision", contract: "NEXT_ACTION", reason, output: null, composition: { id: "direct-choice", version: "1" }, answers: null, fallback: { id: "fallback", output: "WAIT" }, pause: null, decisionPath: null, attempt: 1, auditErrors: [] }

// @ts-expect-error Authority flags are exact false, never broad boolean.
const narrowedAuthority: Authority = { billingClass: "included", paidCapacity: true, permissionEscalation: false, verificationWaived: false, completionWaived: false, completionPreconditionsPassed: false }
void narrowedAuthority
