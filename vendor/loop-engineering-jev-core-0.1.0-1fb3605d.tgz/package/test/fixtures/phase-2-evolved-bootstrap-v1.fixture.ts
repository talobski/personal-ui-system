import { phaseEntryBootstrapV1 } from "./phase-entry-bootstrap-v1.fixture.ts"

/** Separate P2-08 snapshot; it is not the canonical Phase-entry state. */
export const phase2EvolvedBootstrapV1 = {
  ...structuredClone(phaseEntryBootstrapV1),
  activeUnit: { taskId: "phase-2-remediation-producer" },
  lifetime: { agentRunsUsed: 10, agentRunCeiling: 16, paidSpendCeiling: 0, paidSpendUsed: 0 },
  phasePlan: {
    ...structuredClone(phaseEntryBootstrapV1.phasePlan),
    counters: { agentRuns: 2, leadToWorkerTurns: 4, phaseAttempts: 1, activeWorkers: 1 },
  },
  inFlight: [{ runId: "phase-2-remediation-1", taskId: "phase-2-remediation-producer", attempt: 1, workspaceId: "phase-2-remediation-worktree" }],
} as const
