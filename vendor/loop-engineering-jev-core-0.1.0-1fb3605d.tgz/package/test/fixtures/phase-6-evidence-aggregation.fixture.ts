export const p6EvidenceAggregationFixtures = {
  leadPass: { source: "LEAD" as const, candidateCommit: "candidate", scopeHash: "scope", outcome: "PASS" as const, detailHash: "lead-detail", fresh: false },
  freshPass: { source: "FRESH_VERIFIER" as const, candidateCommit: "candidate", scopeHash: "scope", outcome: "PASS" as const, detailHash: "fresh-pass-detail", fresh: true },
  freshProductFailure: { source: "FRESH_VERIFIER" as const, candidateCommit: "candidate", scopeHash: "scope", outcome: "FAIL_PRODUCT" as const, detailHash: "fresh-product-detail", fresh: true },
  freshContractFailure: { source: "FRESH_VERIFIER" as const, candidateCommit: "candidate", scopeHash: "scope", outcome: "FAIL_CONTRACT" as const, detailHash: "fresh-contract-detail", fresh: true },
  freshEnvironmentBlock: { source: "FRESH_VERIFIER" as const, candidateCommit: "candidate", scopeHash: "scope", outcome: "BLOCKED_ENVIRONMENT" as const, detailHash: "fresh-environment-detail", fresh: true },
  freshCapabilityBlock: { source: "FRESH_VERIFIER" as const, candidateCommit: "candidate", scopeHash: "scope", outcome: "BLOCKED_CAPABILITY" as const, detailHash: "fresh-capability-detail", fresh: true },
} as const
