import assert from "node:assert/strict"
import { createHash } from "node:crypto"
import { readFile } from "node:fs/promises"
import { test } from "node:test"
import { CLAUDE_STRONG_WORKER_PROFILE, CODEX_STRONG_WORKER_PROFILE, createSyntheticNegativeReceipts, validateNegativeAdmissionFixture, validateWorkerProfile } from "../src/profile-routing.ts"
import { acceptEvidence, admitSameVerifierRecovery, bindModelClass, classifyVerificationOutcome, composeModelClassPacket, consumeMaxApproval, createStrongActivationPlan, decideContinuation, filterRoutesForClass, preflightVerifier } from "../src/runtime-control.ts"

const freshPass = { source: "FRESH_VERIFIER" as const, candidateCommit: "candidate", scopeHash: "scope", outcome: "PASS" as const }
const preflight = { verifierId: "standard-verifier", candidateCommit: "candidate", candidateHash: "candidate-hash", controlHash: "controls-hash", expectedCandidateCommit: "candidate", expectedCandidateHash: "candidate-hash", expectedControlHash: "controls-hash", currentPathCapabilities: ["filesystem", "shell", "typescript"], requiredCapabilities: ["filesystem", "typescript"], protectedRunReserved: true as const }

test("P5-01 continuation executes the sole bounded option, chooses only among multiple options, and fails closed", () => {
  assert.deepEqual(decideContinuation([{ id: "same-verifier", kind: "retry", safe: true, withinHeadroom: true }], false, 1), { action: "EXECUTE", option: { id: "same-verifier", kind: "retry", safe: true, withinHeadroom: true }, logged: true })
  assert.equal(decideContinuation([{ id: "retry", kind: "retry", safe: true, withinHeadroom: true }, { id: "owner", kind: "interrupt", safe: true, withinHeadroom: true }], false, 1).action, "DECIDE")
  for (const [result, reason] of [[decideContinuation([{ id: "retry", kind: "retry", safe: true, withinHeadroom: true }], true, 1), "HARD_BOUNDARY"], [decideContinuation([{ id: "retry", kind: "retry", safe: true, withinHeadroom: true }], false, 0), "HEADROOM_EXHAUSTED"], [decideContinuation([{ id: "unsafe", kind: "retry", safe: false, withinHeadroom: true }], false, 1), "NO_SAFE_OPTION"]] as const) { assert.equal(result.action, "FAIL_CLOSED"); if (result.action === "FAIL_CLOSED") assert.equal(result.reason, reason) }
})

test("P5-02 preflight binds current capability plus exact candidate and controls before protected dispatch", () => {
  const receipt = preflightVerifier(preflight); assert.ok(receipt.ok); if (receipt.ok) assert.equal(receipt.value.protectedRunConsumed, false)
  for (const drift of [{ expectedCandidateCommit: "other" }, { expectedCandidateHash: "other" }, { expectedControlHash: "other" }, { currentPathCapabilities: ["filesystem"] }]) assert.equal(preflightVerifier({ ...preflight, ...drift }).ok, false)
})

test("P5-03 outcomes are closed and P5-04 provenance cannot be impersonated", () => {
  assert.deepEqual([classifyVerificationOutcome({}), classifyVerificationOutcome({ productFailure: true }), classifyVerificationOutcome({ contractFailure: true }), classifyVerificationOutcome({ environmentBlocked: true }), classifyVerificationOutcome({ capabilityBlocked: true })], ["PASS", "FAIL_PRODUCT", "FAIL_CONTRACT", "BLOCKED_ENVIRONMENT", "BLOCKED_CAPABILITY"])
  assert.ok(acceptEvidence(freshPass, true).ok)
  assert.equal(acceptEvidence({ ...freshPass, source: "LEAD" }, true).ok, false)
  assert.equal(acceptEvidence({ ...freshPass, source: "BLOCKED_ENVIRONMENT", outcome: "PASS" }, false).ok, false)
  assert.ok(acceptEvidence({ ...freshPass, source: "BLOCKED_ENVIRONMENT", outcome: "BLOCKED_CAPABILITY" }, false).ok)
})

test("P5-05 same-verifier recovery is identity, scope, controls, permissions, and capability bound", () => {
  const initial = { verifierId: "v", candidateCommit: "c", scopeHash: "s", controlHash: "control", permissionHash: "permissions" }
  const request = { ...initial, initial, newAgentRun: false as const, network: false as const, credentialAccess: false as const, paidSpend: 0 as const, concurrency: 1 as const, productMutation: false as const, testMutation: false as const }
  assert.ok(admitSameVerifierRecovery(request).ok)
  for (const drift of [{ verifierId: "other" }, { candidateCommit: "other" }, { scopeHash: "other" }, { controlHash: "other" }, { permissionHash: "other" }, { newAgentRun: true }, { network: true }, { credentialAccess: true }, { paidSpend: 1 }, { concurrency: 2 }, { productMutation: true }, { testMutation: true }]) assert.equal(admitSameVerifierRecovery({ ...request, ...drift } as never).ok, false)
})

test("P5-06 model class binds profile hashes, precedes class-filtered routing, and rejects fallback", () => {
  const standard = bindModelClass(CODEX_STRONG_WORKER_PROFILE, "STANDARD"), strong = bindModelClass(CODEX_STRONG_WORKER_PROFILE, "STRONG")
  assert.ok(standard.bindingHash !== strong.bindingHash)
  const singleton = composeModelClassPacket(["STANDARD"], "r", "d"); assert.ok(singleton.ok); if (singleton.ok) assert.equal(singleton.value, null, "singleton class skips Jev")
  const packet = composeModelClassPacket(["STANDARD", "STRONG"], "r", "d"); assert.ok(packet.ok && packet.value && packet.value.contract === "MODEL_CLASS")
  assert.equal(filterRoutesForClass([strong], "STANDARD").ok, false)
  const filtered = filterRoutesForClass([strong], "STRONG"); assert.ok(filtered.ok); if (filtered.ok) assert.equal(filtered.value.length, 1)
  assert.equal(filterRoutesForClass([strong], "MAX").ok, false)
})

test("P5-07 Strong declarations are exact, admission-tested, and Standard artifact bytes remain unchanged", async () => {
  for (const [profile, artifact] of [[CODEX_STRONG_WORKER_PROFILE, "profiles/codex-strong-worker.profile.json"], [CLAUDE_STRONG_WORKER_PROFILE, "profiles/claude-strong-worker.profile.json"]] as const) {
    assert.deepEqual(JSON.parse(await readFile(artifact, "utf8")), profile); assert.ok(validateWorkerProfile(profile).ok); assert.ok(validateNegativeAdmissionFixture(createSyntheticNegativeReceipts(profile), profile).ok)
  }
  assert.equal(CODEX_STRONG_WORKER_PROFILE.model, "gpt-5.6-sol"); assert.equal(CLAUDE_STRONG_WORKER_PROFILE.model, "claude-opus-5")
  const digest = async (path: string) => createHash("sha256").update(await readFile(path, "utf8")).digest("hex")
  assert.equal(await digest("profiles/codex-worker.profile.json"), "7af2024bf114c62dbfba30408f9acdb716cb19695b0551ff548587dea1bcd811")
  assert.equal(await digest("profiles/claude-worker.profile.json"), "47cff0466630a73dea24fda1b9001437d867a03b7d4ee812a9feaec7b7bff155")
})

test("P5-08 MAX is recommendation-only until exact one-use approval and cannot replay", () => {
  const recommendation = { taskId: "task", profileId: "max-profile", model: "max-model", effort: "medium" as const, recommended: true as const }
  const approval = { ...recommendation, approvalId: "approval", nonce: "nonce", ownerApproved: true as const }
  assert.equal(consumeMaxApproval(recommendation, undefined, new Set()).ok, false)
  assert.ok(consumeMaxApproval(recommendation, approval, new Set()).ok)
  assert.equal(consumeMaxApproval(recommendation, approval, new Set(["approval"])).ok, false)
  assert.equal(consumeMaxApproval({ ...recommendation, taskId: "other" }, approval, new Set()).ok, false)
})

test("P5-09/P5-11 Strong activation is Lead-only, post-PASS, hash-bound, and has rollback evidence", () => {
  const strong = bindModelClass(CODEX_STRONG_WORKER_PROFILE, "STRONG")
  const plan = createStrongActivationPlan("candidate", freshPass, [strong], "registry-before", "controls")
  assert.ok(plan.ok); if (plan.ok) { assert.equal(plan.value.activation, false); assert.equal(plan.value.leadOnly, true); assert.equal(plan.value.rollback.beforeRegistryHash, "registry-before") }
  assert.equal(createStrongActivationPlan("candidate", { ...freshPass, source: "LEAD" }, [strong], "registry", "controls").ok, false)
  assert.equal(createStrongActivationPlan("other", freshPass, [strong], "registry", "controls").ok, false)
})
