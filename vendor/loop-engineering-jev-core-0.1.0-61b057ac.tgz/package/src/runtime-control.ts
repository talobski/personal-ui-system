/** Phase 5 pure control-plane contracts.  They neither dispatch nor mutate live state. */
import { digestQuestions } from "./packet.ts"
import { sha256, stableJson } from "./state-policy.ts"
import type { Check } from "./state-policy.ts"
import type { AdmissionPacket, Question } from "./types.ts"
import type { WorkerProfile } from "./profile-routing.ts"

const fail = <T>(...errors: string[]): Check<T> => ({ ok: false, errors })
const text = (value: unknown): value is string => typeof value === "string" && value.length > 0
const hash = (value: unknown) => sha256(stableJson(value))
export const MODEL_CLASS_V1 = "loop-model-class/1"
export type ModelClass = "STANDARD" | "STRONG" | "MAX"
export type ContinuationContract = "RETRY_STRATEGY" | "HUMAN_INTERRUPT"

export type ContinuationOption = { id: string; kind: "retry" | "interrupt"; safe: boolean; withinHeadroom: boolean }
export type ContinuationResult = { action: "EXECUTE"; option: ContinuationOption; logged: true } | { action: "DECIDE"; contract: ContinuationContract; options: readonly ContinuationOption[] } | { action: "FAIL_CLOSED"; reason: "HARD_BOUNDARY" | "HEADROOM_EXHAUSTED" | "NO_SAFE_OPTION" }
/** A single safe bounded option is never sent to Jev. */
export function decideContinuation(options: readonly ContinuationOption[], hardBoundary: boolean, headroom: number): ContinuationResult {
  if (hardBoundary) return { action: "FAIL_CLOSED", reason: "HARD_BOUNDARY" }
  if (!Number.isSafeInteger(headroom) || headroom <= 0) return { action: "FAIL_CLOSED", reason: "HEADROOM_EXHAUSTED" }
  const safe = options.filter(option => text(option.id) && option.safe && option.withinHeadroom)
  if (safe.length === 0) return { action: "FAIL_CLOSED", reason: "NO_SAFE_OPTION" }
  if (safe.length === 1) return { action: "EXECUTE", option: safe[0]!, logged: true }
  return { action: "DECIDE", contract: safe.some(option => option.kind === "interrupt") ? "HUMAN_INTERRUPT" : "RETRY_STRATEGY", options: safe }
}

export type VerifierPreflight = { verifierId: string; candidateCommit: string; candidateHash: string; controlHash: string; expectedCandidateCommit: string; expectedCandidateHash: string; expectedControlHash: string; currentPathCapabilities: readonly string[]; requiredCapabilities: readonly string[]; protectedRunReserved: true }
export type PreDispatchReceipt = { schemaVersion: "loop-pre-verifier-receipt/1"; verifierId: string; candidateCommit: string; candidateHash: string; controlHash: string; dispatchAllowed: true; protectedRunConsumed: false }
export function preflightVerifier(input: VerifierPreflight): Check<PreDispatchReceipt> {
  if (!text(input.verifierId) || !text(input.candidateCommit) || !text(input.candidateHash) || !text(input.controlHash) || !input.protectedRunReserved || input.candidateCommit !== input.expectedCandidateCommit || input.candidateHash !== input.expectedCandidateHash || input.controlHash !== input.expectedControlHash || !input.requiredCapabilities.every(capability => input.currentPathCapabilities.includes(capability))) return fail("verifier preflight capability, candidate, or control receipt mismatch")
  return { ok: true, value: { schemaVersion: "loop-pre-verifier-receipt/1", verifierId: input.verifierId, candidateCommit: input.candidateCommit, candidateHash: input.candidateHash, controlHash: input.controlHash, dispatchAllowed: true, protectedRunConsumed: false } }
}

export type VerificationOutcome = "PASS" | "FAIL_PRODUCT" | "FAIL_CONTRACT" | "BLOCKED_ENVIRONMENT" | "BLOCKED_CAPABILITY"
export function classifyVerificationOutcome(input: { productFailure?: boolean; contractFailure?: boolean; environmentBlocked?: boolean; capabilityBlocked?: boolean }): VerificationOutcome {
  if (input.capabilityBlocked) return "BLOCKED_CAPABILITY"
  if (input.environmentBlocked) return "BLOCKED_ENVIRONMENT"
  if (input.contractFailure) return "FAIL_CONTRACT"
  return input.productFailure ? "FAIL_PRODUCT" : "PASS"
}
export type Evidence = { source: "FRESH_VERIFIER" | "LEAD" | "BLOCKED_ENVIRONMENT"; candidateCommit: string; scopeHash: string; outcome: VerificationOutcome }
export function acceptEvidence(evidence: Evidence, requiresFreshVerifier: boolean): Check<Evidence> {
  if (!text(evidence.candidateCommit) || !text(evidence.scopeHash) || !["PASS", "FAIL_PRODUCT", "FAIL_CONTRACT", "BLOCKED_ENVIRONMENT", "BLOCKED_CAPABILITY"].includes(evidence.outcome)) return fail("evidence malformed")
  if (requiresFreshVerifier && (evidence.source !== "FRESH_VERIFIER" || evidence.outcome !== "PASS")) return fail("Lead or blocked evidence cannot satisfy fresh verifier evidence")
  if (evidence.source === "BLOCKED_ENVIRONMENT" && !evidence.outcome.startsWith("BLOCKED_")) return fail("blocked evidence has false provenance")
  return { ok: true, value: evidence }
}

export type RecoveryRequest = { verifierId: string; candidateCommit: string; scopeHash: string; controlHash: string; permissionHash: string; initial: { verifierId: string; candidateCommit: string; scopeHash: string; controlHash: string; permissionHash: string }; newAgentRun: false; network: false; credentialAccess: false; paidSpend: 0; concurrency: 1; productMutation: false; testMutation: false }
export function admitSameVerifierRecovery(request: RecoveryRequest): Check<{ recovery: "SAME_VERIFIER"; attempts: 1 }> {
  const same = request.verifierId === request.initial.verifierId && request.candidateCommit === request.initial.candidateCommit && request.scopeHash === request.initial.scopeHash && request.controlHash === request.initial.controlHash && request.permissionHash === request.initial.permissionHash
  return same && !request.newAgentRun && !request.network && !request.credentialAccess && request.paidSpend === 0 && request.concurrency === 1 && !request.productMutation && !request.testMutation ? { ok: true, value: { recovery: "SAME_VERIFIER", attempts: 1 } } : fail("same-verifier recovery broadened identity, scope, capability, or counters")
}

export type ClassBoundProfile = { profile: WorkerProfile; modelClass: Exclude<ModelClass, "MAX">; profileHash: string; bindingHash: string }
export function bindModelClass(profile: WorkerProfile, modelClass: Exclude<ModelClass, "MAX">): ClassBoundProfile { const profileHash = hash(profile); return { profile, modelClass, profileHash, bindingHash: hash({ modelClass, profileHash }) } }
export function composeModelClassPacket(classes: readonly ModelClass[], runId: string, decisionId: string): Check<AdmissionPacket | null> {
  const unique = [...new Set(classes)].sort()
  if (unique.length === 0) return fail("no admitted model class")
  if (unique.length === 1) return { ok: true, value: null }
  const questions: Question[] = [{ id: "modelClass", type: "choice", instructions: "Select only an admitted model class.", options: unique.map(id => ({ id, description: `admitted ${id} class` })) }]
  return { ok: true, value: { schemaVersion: "loop-jev-admission/1", projectId: "loop-engineering-runtime", runId, decisionId, contract: "MODEL_CLASS", composition: { id: "direct-choice", version: "1" }, admission: { gate: "phase-5-class-admission", questionsDigest: digestQuestions("MODEL_CLASS", questions), authority: { billingClass: "included", paidCapacity: false, permissionEscalation: false, verificationWaived: false, completionWaived: false, completionPreconditionsPassed: false } }, state: { modelClasses: unique }, questions } }
}
/** ROUTE_PROFILE may only see profiles selected by the preceding class decision. */
export function filterRoutesForClass(profiles: readonly ClassBoundProfile[], selected: ModelClass): Check<readonly ClassBoundProfile[]> { if (selected === "MAX") return fail("MAX has no autonomous route"); const filtered = profiles.filter(profile => profile.modelClass === selected); return filtered.length ? { ok: true, value: filtered } : fail("cross-class fallback is forbidden") }

export type MaxRecommendation = { taskId: string; profileId: string; model: string; effort: "medium"; recommended: true }
export type OwnerApproval = MaxRecommendation & { approvalId: string; nonce: string; ownerApproved: true }
export function consumeMaxApproval(recommendation: MaxRecommendation, approval: OwnerApproval | undefined, usedApprovalIds: ReadonlySet<string>): Check<{ dispatch: "MAX"; consumedApprovalId: string }> {
  if (!approval || !text(approval.approvalId) || !text(approval.nonce) || usedApprovalIds.has(approval.approvalId) || !approval.ownerApproved || approval.taskId !== recommendation.taskId || approval.profileId !== recommendation.profileId || approval.model !== recommendation.model || approval.effort !== recommendation.effort) return fail("MAX approval missing, mismatched, persistent, or replayed")
  return { ok: true, value: { dispatch: "MAX", consumedApprovalId: approval.approvalId } }
}

export type StrongActivationPlan = { schemaVersion: "loop-strong-activation-plan/1"; candidateCommit: string; verificationEvidenceHash: string; profiles: readonly { profileId: string; profileHash: string }[]; preconditions: { registryHash: string; controlsHash: string; exactPass: true }; rollback: { beforeRegistryHash: string; required: true }; activation: false; leadOnly: true }
export function createStrongActivationPlan(candidateCommit: string, verification: Evidence, profiles: readonly ClassBoundProfile[], registryHash: string, controlsHash: string): Check<StrongActivationPlan> {
  if (!text(candidateCommit) || verification.candidateCommit !== candidateCommit || !acceptEvidence(verification, true).ok || profiles.length === 0 || !text(registryHash) || !text(controlsHash) || profiles.some(profile => profile.modelClass !== "STRONG")) return fail("Strong activation requires exact fresh PASS and Strong-only hashes")
  return { ok: true, value: { schemaVersion: "loop-strong-activation-plan/1", candidateCommit, verificationEvidenceHash: hash(verification), profiles: profiles.map(profile => ({ profileId: profile.profile.id, profileHash: profile.bindingHash })), preconditions: { registryHash, controlsHash, exactPass: true }, rollback: { beforeRegistryHash: registryHash, required: true }, activation: false, leadOnly: true } }
}
