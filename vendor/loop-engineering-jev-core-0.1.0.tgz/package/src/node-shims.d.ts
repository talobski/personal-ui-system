declare module "node:crypto" {
  export function createHash(algorithm: string): { update(data: string): { digest(encoding: "hex"): string } }
}

declare module "node:fs/promises" {
  export type Stats = { isFile(): boolean; isSymbolicLink(): boolean; mode: number; dev: number; ino: number }
  export function lstat(path: string): Promise<Stats>
  export function readFile(path: string, encoding: "utf8"): Promise<string>
  export function writeFile(path: string, data: string, options?: { encoding?: "utf8"; flag?: string; mode?: number }): Promise<void>
  export function rename(from: string, to: string): Promise<void>
  export function unlink(path: string): Promise<void>
  export function chmod(path: string, mode: number): Promise<void>
  export function mkdtemp(prefix: string): Promise<string>
  export function rm(path: string, options: { recursive: boolean; force: boolean }): Promise<void>
  export function symlink(target: string, path: string): Promise<void>
  export function appendFile(path: string, data: string, encoding?: string): Promise<void>
  export function mkdir(path: string, options?: { recursive?: boolean }): Promise<void>
  export function open(path: string, flags: string): Promise<{ writeFile(data: string, encoding?: string): Promise<void>; close(): Promise<void> }>
  export function stat(path: string): Promise<Stats>
}

declare module "node:path" { export function dirname(path: string): string; export function basename(path: string): string; export function join(...parts: string[]): string; export function resolve(...paths: string[]): string }
declare module "node:os" { export function homedir(): string }
declare module "node:fs" { export function readFileSync(path: string | number, encoding: string): string }
declare module "node:util" { export function parseArgs(options: unknown): { values: Record<string, string | boolean | undefined> } }
declare module "node:process" { export const argv: string[]; export let exitCode: number; export const env: Record<string, string | undefined>; export function cwd(): string; export const pid: number }
declare const process: { pid: number; env: Record<string, string | undefined>; cwd(): string; exitCode: number }

declare module "node:assert/strict" {
  const assert: {
    equal(actual: unknown, expected: unknown, message?: string): void
    deepEqual(actual: unknown, expected: unknown, message?: string): void
    ok(value: unknown, message?: string): asserts value
    rejects(fn: (() => Promise<unknown>) | Promise<unknown>, error?: RegExp): Promise<void>
  }
  export default assert
}

declare module "node:test" {
  export function test(name: string, fn: () => void | Promise<void>): void
}
