#!/bin/sh
set -eu

source_root=/Users/emmantalob/dev/personal-ui-system/tools/loop/jev
expected_commit=dedf949702e9b869670cbb3bc344d4e1b220f4dd
[ "$(git -C "$source_root" rev-parse HEAD)" = "$expected_commit" ]
git -C "$source_root" diff --quiet

check() {
  expected=$1
  source=$2
  extracted=$3
  [ "$(shasum -a 256 "$source" | awk '{print $1}')" = "$expected" ]
  [ "$(shasum -a 256 "$extracted" | awk '{print $1}')" = "$expected" ]
  cmp -s "$source" "$extracted"
}

check 308cb724802c561453130804b58ce56ddcb1aacd35b081786757b0274a6999dd "$source_root/types.ts" src/types.ts
check 35e977717ac26789442a3f9e19b4ebf60138a915fe23147eb2a3d9fb6b08f977 "$source_root/accept.ts" src/accept.ts
check ad30f7887d4333a22b0c627a325382d74c4223f4380cfdfeb0c32197af18306e "$source_root/packet.ts" src/packet.ts
check 0ee472426f9314c0c5b5f4a7e49a65ece19acd3329133e24d426b50c76db367a "$source_root/compose.ts" src/compose.ts
printf '%s\n' 'provenance: pinned source and controlled extractions match'
